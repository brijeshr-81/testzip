﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IntegrationMappingController.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Controllers
{
    using System;
    using AHC.Odyssey.Integration.API.Models;
    using AHC.Odyssey.Integration.API.Services;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;

    /// <summary>
    /// Controller class for maintenance of integration mapping details
    /// </summary>
    [Authorize]
    [Route("api/map")]
    [ApiController]
    public class IntegrationMappingController : ControllerBase
    {
        /// <summary>
        /// Field to hold integration service instance
        /// </summary>
        private readonly IIntegrationService integrationService;

        /// <summary>
        /// Initialises an instance of <see cref="IntegrationMappingController"/> class
        /// </summary>
        /// <param name="integrationService">The integration service</param>
        public IntegrationMappingController(IIntegrationService integrationService)
        {
            this.integrationService = integrationService;
        }

        /// <summary>
        /// End point to create a new integration mapping 
        /// </summary>
        /// <param name="mappingDetails">The mapping details to be used to create</param>
        /// <returns>Action Result/Response</returns>
        [HttpPost("create")]
        [Authorize("mapping:write")]
        public IActionResult CreateMapping(DtoIntegrationMapping mappingDetails)
        {
            try
            {
                if (mappingDetails == null || !mappingDetails.IsValid)
                {
                    return BadRequest();
                }

                var recordId = this.integrationService.AddMapping(mappingDetails);
                if (recordId > 0)
                {
                    return Ok();
                }

                return Conflict();
            }
            catch
            {
                throw new InvalidOperationException("Failed to add mapping entry.");
            }
        }

        /// <summary>
        /// End point to retrieve integration mapping  for a given odyssey patient Id
        /// </summary>
        /// <param name="odysseyPatientId">The odyssey patient Id for which mapping is to be retrieved</param>
        /// <returns>Action Result/Response</returns>
        [Authorize("mapping:read")]
        [HttpGet("{odysseyPatientId}")]
        public IActionResult GetMapping(Guid odysseyPatientId)
        {
            try
            {
                if (odysseyPatientId == Guid.Empty)
                {
                    return BadRequest();
                }

                var dtoMapping = this.integrationService.GetMappingByOdysseyPatientId(odysseyPatientId);
                if (dtoMapping == null)
                {
                    return NoContent();
                }

                return Ok(dtoMapping);
            }
            catch
            {
                throw new InvalidOperationException("Failed to retrieve mapping.");
            }
        }

        /// <summary>
        /// End point to retrieve all integration mapping 
        /// </summary>
        /// <returns>Action Result/Response</returns>
        [Authorize("mapping:read")]
        [HttpGet]
        public IActionResult GetAllMapping()
        {
            try
            {
                var dtoMapping = this.integrationService.GetAllMapping();
                if (dtoMapping == null)
                {
                    return NoContent();
                }

                return Ok(dtoMapping);
            }
            catch
            {
                throw new InvalidOperationException("Failed to retrieve mapping details.");
            }
        }

        /// <summary>
        /// End point to update existing integration mapping 
        /// </summary>
        /// <param name="mappingDetails">The mapping details to be used to update</param>
        /// <returns>Action Result/Response</returns>
        [HttpPost("update")]
        [Authorize("mapping:write")]
        public IActionResult UpdateMapping(DtoIntegrationMapping mappingDetails)
        {
            try
            {
                if (mappingDetails == null || !mappingDetails.IsValid)
                {
                    return BadRequest();
                }

                var recordId = this.integrationService.UpdateMapping(mappingDetails, out bool alreadyUpdated);
                if (alreadyUpdated)
                {
                    return Ok("The given record already updated");
                }

                if (recordId > 0)
                {
                    return Ok();
                }

                return NoContent();
            }
            catch
            {
                throw new InvalidOperationException("Failed to update mapping entry.");
            }
        }
    }
}
