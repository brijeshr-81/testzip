﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ImportController.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Controllers
{
    using System;
    using System.Net;
    using System.Net.Http;
    using AHC.Odyssey.Integration.API.Services;
    using AHC.Odyssey.Integration.API.ThirdParty;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Newtonsoft.Json;
    using Config = Microsoft.Extensions.Configuration;

    /// <summary>
    /// Controller class to import assessment details
    /// </summary>
    [Route("api/import")]
    [ApiController]
    [Authorize]
    public class ImportController : ControllerBase
    {
        /// <summary>
        /// Field for configuration
        /// </summary>
        protected readonly Config.IConfiguration Configuration;

        /// <summary>
        /// Field for import service 
        /// </summary>
        protected readonly IImportService ImportService;

        /// <summary>
        /// Field for integration service 
        /// </summary>
        protected readonly IIntegrationService IntegrationService;

        /// <summary>
        /// Field for third party services
        /// </summary>
        protected readonly IThirdPartyService ThirdPartyServices;

        /// <summary>
        /// Field to hold logger object
        /// </summary>
        private readonly ILogger<ImportController> logger;

        /// <summary>
        /// Field to hold follow up session Id
        /// </summary>
        private string followUpSessionId;

        /// <summary>
        /// Initialises an instance of <see cref="ImportController"/> class
        /// </summary>
        /// <param name="importService">The import service</param>
        /// <param name="integrationService">The integration service</param>
        /// <param name="ThirdPartyServices"> The Third party services</param>
        /// <param name="configuration">The configuration</param>
        /// <param name="logger">The logging mechanism</param>
        public ImportController(IImportService importService, IIntegrationService integrationService, IThirdPartyService thirdPartyServices, Config.IConfiguration configuration, ILogger<ImportController> logger)
        {
            this.ImportService = importService;
            this.Configuration = configuration;
            this.IntegrationService = integrationService;
            this.ThirdPartyServices = thirdPartyServices;
            this.logger = logger;
        }

        /// <summary>
        /// End point to transfer data 
        /// </summary>
        /// <param name="odysseyPatientDomainId">Odyssey Patient Domain Id</param>
        /// <returns>status code</returns>
        [HttpPost("TransferData/{odysseyPatientDomainId}")]
        [Authorize("import:transfer")]
        public IActionResult TransferData(Guid odysseyPatientDomainId)
        {
            this.logger.LogInformation("Entering - TransferData");
            var callbackNumber = Request.Form["Patient.CallbackNumber"];
            this.logger.LogInformation("Forename :" + Request.Form["Patient.Forename"]);
            this.logger.LogInformation("Surname :" + Request.Form["Patient.Surname"]);
            if (!Guid.TryParse(Request.Form["transactionId"], out Guid transactionId) || transactionId == Guid.Empty)
            {
                this.logger.LogError($"{HttpStatusCode.BadRequest} : Transaction Id is empty or invalid.");
                return this.BadRequest("Transaction Id is empty or invalid.");
            }

            try
            {
                if (!string.IsNullOrEmpty(callbackNumber))
                {
                    this.logger.LogInformation($"[{transactionId}] - The callback number is: {callbackNumber}");
                }

                var domainMapping = this.IntegrationService.GetMappingByOdysseyPatientId(odysseyPatientDomainId);
                if (domainMapping == null)
                {
                    this.logger.LogError($"[{transactionId}] - {HttpStatusCode.InternalServerError} : Supplied Domain Id does not match any known mapping records.");
                    return this.StatusCode(StatusCodes.Status500InternalServerError, "Supplied Domain Id does not match any known mapping records.");
                }

                if (domainMapping.HasOdysseyCore && string.IsNullOrEmpty(domainMapping.OdysseyServiceUrl))
                {
                    this.logger.LogError($"[{transactionId}] - {HttpStatusCode.InternalServerError} : Odyssey service url is null or empty.");
                    return this.StatusCode(StatusCodes.Status500InternalServerError, "Odyssey service url is null or empty.");
                }

                var packageFile = Request.Form.Files;
                if (packageFile.Count != 1)
                {
                    this.logger.LogError($"[{transactionId}] - {HttpStatusCode.BadRequest} : Package file is corrupted.");
                    return this.BadRequest("Package file is corrupted.");
                }

                HttpResponseMessage response = null;
                if (domainMapping.HasOdysseyCore)
                {
                    response = this.ImportService.TransferData(domainMapping.OdysseyCoreDomainId, domainMapping.OdysseyServiceUrl, packageFile[0], transactionId);

                    switch (response.StatusCode)
                    {
                        case HttpStatusCode.OK:
                            var sessionId = response.Content.ReadAsStringAsync().Result;
                            this.followUpSessionId = JsonConvert.DeserializeObject<string>(sessionId);
                            this.logger.LogInformation("TransferData - ImportService reports OK");
                            break;
                        case HttpStatusCode.BadRequest:
                            this.logger.LogError($"[{transactionId}] - {HttpStatusCode.BadRequest} : Failure due to invalid data transferred to the Import Service.");
                            return this.BadRequest("Failure due to invalid data transferred to the Import Service.");
                        case HttpStatusCode.Unauthorized:
                            this.logger.LogError($"[{transactionId}] - {HttpStatusCode.Unauthorized} : Unauthorised attempt to connect to the Import Service.");
                            return this.Unauthorized("Unauthorised attempt to connect to the Import Service.");
                        case HttpStatusCode.Forbidden:
                            this.logger.LogError($"[{transactionId}] - {HttpStatusCode.Unauthorized} : Access to the Import Service is forbidden.");
                            return this.Unauthorized("Access to the Import Service is forbidden.");
                        case HttpStatusCode.InternalServerError:
                            this.logger.LogError($"[{transactionId}] - {HttpStatusCode.InternalServerError} : Import service failed to record the data.");
                            return this.StatusCode(StatusCodes.Status500InternalServerError, "Import service failed to record the data.");
                        default:
                            this.logger.LogError($"[{transactionId}] - {response.StatusCode} : Unhandled return from Import Service.");
                            return this.StatusCode(StatusCodes.Status500InternalServerError, "Unhandled return from Import Service.");
                    }
                }

                ThirdPartyData thirdPartyData = JsonConvert.DeserializeObject<ThirdPartyData>(domainMapping.ThirdPartyData);

                if (thirdPartyData == null)
                {
                    this.logger.LogError($"[{transactionId}] - Unable to parse ThirdPartyData.");
                    return this.StatusCode(StatusCodes.Status500InternalServerError, "Unable to parse ThirdPartyData.");
                }
                
                // Send assessment to ThirdParty
                return this.ThirdPartySubmissionResult(transactionId, thirdPartyData, domainMapping.ReferrerName, domainMapping.HasOdysseyCore);
            }
            catch (Exception ex)
            {
                this.logger.LogError($"[{transactionId}] - {HttpStatusCode.InternalServerError} : Failed to fetch the mapping details. {ex.Message}");
                return this.StatusCode(StatusCodes.Status500InternalServerError, "Exception thrown when attempting to transfer data.");
            }
        }

        /// <summary>
        /// Submission of assessment details to the third party
        /// </summary>
        /// <param name="sessionId">The session Id</param>
        /// <param name="thirdPartyData">The third party data</param>
        /// <returns>a response based on the submission result</returns>
        private IActionResult ThirdPartySubmissionResult(Guid sessionId, ThirdPartyData thirdPartyData, string referrerName, bool hasOdysseyCore)
        {
            this.ThirdPartyServices.FollowUpSessionId = this.followUpSessionId;
            this.ThirdPartyServices.ThirdPartyData = thirdPartyData;

            var isAssessmentSentToThirdParty = this.ThirdPartyServices.SendAssessmentToThirdParty(Request.Form, sessionId, referrerName);
            if (isAssessmentSentToThirdParty)
            {
                var importServiceText = hasOdysseyCore ? "Odyssey import service and " : "";
                var followupText = hasOdysseyCore ? $" Follow Up Session Id : { this.followUpSessionId }." : "";

                var message = $"Data transferred to {importServiceText}third party.{followupText}";

                this.logger.LogInformation($"[{sessionId}] - {HttpStatusCode.OK} : {message}");
                return this.Ok($"{message}");
            }

            this.logger.LogInformation($"[{sessionId}] - {HttpStatusCode.InternalServerError} : Failed to submit assessment details to third party service. Follow Up Session Id : { this.followUpSessionId }.");
            return this.StatusCode(StatusCodes.Status500InternalServerError, "Failed to submit assessment details to third party service.");
        }
    }
}