﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ErrorController.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Controllers
{
    using System;
    using Microsoft.AspNetCore.Diagnostics;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Mvc;

    /// <summary>
    /// Error controller class
    /// </summary>
    [ApiController]
    public class ErrorController : ControllerBase
    {
        /// <summary>
        /// End point for development environment error page
        /// </summary>
        /// <param name="webHostEnvironment">Web Host Environment</param>
        /// <returns>Returns IActionResult object</returns>
        [Route("/error-local-development")]
        public IActionResult ErrorLocalDevelopment([FromServices] IWebHostEnvironment webHostEnvironment)
        {
            if (webHostEnvironment.EnvironmentName != "Development")
            {
                throw new InvalidOperationException(
                    "This shouldn't be invoked in non-development environments.");
            }

            var context = HttpContext.Features.Get<IExceptionHandlerFeature>();

            return this.Problem(detail: context.Error.StackTrace, title: context.Error.Message);
        }

        /// <summary>
        /// End point for non-development environment error page
        /// </summary>
        /// <returns>Returns IActionResult object</returns>
        [Route("/error")]
        public IActionResult Error()
        {
            var context = HttpContext.Features.Get<IExceptionHandlerFeature>();
            return this.Problem(detail: context.Error.StackTrace, title: context.Error.Message);
        }
    }
}