// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Startup.cs" company="Advanced Health & Care">
//   Copyright � Advanced Health & Care 2021
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Net.Security;
    using System.Security.Cryptography.X509Certificates;
    using AHC.Odyssey.Integration.API.DAL;
    using AHC.Odyssey.Integration.API.Mappers;
    using AHC.Odyssey.Integration.API.Services;
    using Microsoft.AspNetCore.Authentication.JwtBearer;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Diagnostics.HealthChecks;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Diagnostics.HealthChecks;
    using Microsoft.Extensions.Hosting;
    using Microsoft.IdentityModel.Tokens;
    using Newtonsoft.Json;
    using Serilog;

    /// <summary>
    /// Class to configure Services and app's request pipeline
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// Initialises a new instance of <see cref="Startup"/>class
        /// </summary>
        /// <param name="configuration">The application configuration properties</param>
        public Startup(IConfiguration configuration)
        {
            this.Configuration = configuration;
        }

        /// <summary>
        /// Gets the application configuration properties.
        /// </summary>
        public IConfiguration Configuration { get; }

        /// <summary>
        /// This method gets called by the runtime. Use this method to add services to the container.
        /// </summary>
        /// <param name="services">Collection of service descriptors</param>        
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();

            if (this.RunningInternalTesting())
            {
                services.AddScoped<IDataContext, InMemoryDataContext>();
            }
            else
            {
                services.AddTransient<IDataContext, DataContext>();
            }

            services.AddHttpContextAccessor();
            this.ConfigureAuthorization(services);
            this.ConfigureAuthentication(services);
            services.AddSingleton<IMutualAuthService, MutualAuthService>();
            services.AddSingleton<IAuthorizationHandler, ScopeHandler>();
            services.AddScoped<IIntegrationService, IntegrationService>();
            services.AddScoped<IImportService, ImportService>();
            services.AddScoped<IThirdPartyService, ThirdPartyServices>();
            this.SetUpAutoMapper(services);
            this.SetUpHealthChecks(services);
            this.SetUpHttpClientFactory(services);
        }

        /// <summary>
        /// Configure authorization
        /// </summary>
        /// <param name="services">Collection of service descriptors</param>
        public virtual void ConfigureAuthorization(IServiceCollection services)
        {
            try
            {
                Log.Information("Configuring Authorization");

                var region = this.Configuration["AWSCognito_Region"];
                var userPoolId = this.Configuration["AWSCognito_UserPoolId"];
                var issuer = $"https://cognito-idp.{region}.amazonaws.com/{userPoolId}";

                services.AddAuthorization(options =>
                {
                    options.AddPolicy("mapping:read", policy => policy.Requirements.Add(new ScopeRequirement("mapping:read", issuer)));
                    options.AddPolicy("mapping:write", policy => policy.Requirements.Add(new ScopeRequirement("mapping:write", issuer)));
                    options.AddPolicy("import:transfer", policy => policy.Requirements.Add(new ScopeRequirement("import:transfer", issuer)));
                });
            }
            catch (Exception e)
            {
                Log.Error(e, "Configuring Authorization");
                throw;
            }
        }

        /// <summary>
        /// Configure authentication 
        /// </summary>
        /// <param name="services">Collection of service descriptors</param>
        public virtual void ConfigureAuthentication(IServiceCollection services)
        {
            Log.Information("Configuring Authentication");

            var region = this.Configuration["AWSCognito_Region"];
            var userPoolId = this.Configuration["AWSCognito_UserPoolId"];

            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(t =>
            {
                t.SaveToken = true;
                t.Authority = $"https://cognito-idp.{region}.amazonaws.com/{userPoolId}";
                t.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKeyResolver = (s, securityToken, identifier, parameters) =>
                    {
                        //// Get JsonWebKeySet from AWS
                        var json = new WebClient().DownloadString(parameters.ValidIssuer + "/.well-known/jwks.json");

                        //// Serialize the result
                        return JsonConvert.DeserializeObject<JsonWebKeySet>(json).Keys;
                    },
                    ValidateIssuer = true,
                    ValidIssuer = $"https://cognito-idp.{region}.amazonaws.com/{userPoolId}",
                    ValidateLifetime = true,
                    LifetimeValidator = (before, expires, token, param) => expires > DateTime.UtcNow,
                    ValidateAudience = false
                };
            });
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        /// </summary>
        /// <param name="app">Application request parameter</param>
        /// <param name="env">Web hosting environment of the application</param>
        /// <param name="dataContext">The data context</param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IDataContext dataContext)
        {
            dataContext.PerformMigration();

            var errorPage = env.IsDevelopment() ? "/error-local-development" : "/error";
            app.UseExceptionHandler(errorPage);

            /* Authentication from rest api is not included once authentication is made available this can be uncommented*/
            //// app.UseHttpsRedirection();

            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseSerilogRequestLogging();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapHealthChecks("/healthcheck", GetHealthCheckOptions());
                endpoints.MapHealthChecks("/healthcheck/Domain/{domainId}", GetHealthCheckOptions());
            });
        }

        /// <summary>
        /// Sets up service for health check of the application
        /// </summary>
        /// <param name="services">Collection of service descriptors</param>
        private void SetUpHealthChecks(IServiceCollection services)
        {
            services.AddHealthChecks().AddCheck<GetAssemblyVersion>("assemblyversion");
            services.AddHealthChecks().AddCheck<DatabaseHealthCheck>("DB Health");
            services.AddHealthChecks().AddCheck<DomainImportServiceHealthCheck>("Import Service");
        }

        /// <summary>
        /// Sets up the auto mapper for defined profiles types.
        /// </summary>
        /// <param name="services">Collection of service descriptors</param>
        private void SetUpAutoMapper(IServiceCollection services)
        {
            services.AddAutoMapper(MapperHelper.MapperProfileTypes);
        }

        /// <summary>
        /// Gets the health check options to be included 
        /// </summary>
        /// <returns>Health check options</returns>
        private HealthCheckOptions GetHealthCheckOptions()
        {
            // Set up the response from the health check.
            // Appending the assembly versions into the response so we can view it.
            // Other checks added in SetUpHealthChecks will also be included in the body
            var importServiceHealthCheckResult = new List<object>();
            return new HealthCheckOptions
            {
                ResultStatusCodes =
                {
                    [HealthStatus.Healthy] = StatusCodes.Status200OK,
                    [HealthStatus.Degraded] = StatusCodes.Status200OK,
                    [HealthStatus.Unhealthy] = StatusCodes.Status503ServiceUnavailable
                },

                ResponseWriter = async (c, r) =>
                {
                    c.Response.ContentType = "application/json";

                    foreach (var entry in r.Entries)
                    {
                        if (entry.Value.Data.Count > 0)
                        {
                            importServiceHealthCheckResult.Add(new
                            {
                                status = entry.Value.Status.ToString(),
                                tags = string.Join(",", entry.Value.Tags),
                                description = entry.Value.Description,
                                importservicehealthchecks = entry.Value.Data.Select(x => new
                                {
                                    id = x.Key,
                                    status = x.Value
                                })
                            });
                        }
                        else
                        {
                            importServiceHealthCheckResult.Add(new
                            {
                                status = entry.Value.Status.ToString(),
                                tags = string.Join(",", entry.Value.Tags),
                                description = entry.Value.Description
                            });
                        }
                    }

                    var result = JsonConvert.SerializeObject(new
                    {
                        status = r.Status.ToString(),
                        checkresults = importServiceHealthCheckResult.ToArray()
                    });
                    importServiceHealthCheckResult.Clear();
                    await c.Response.WriteAsync(result);
                }
            };
        }

        /// <summary>
        /// Configure HttpClient factory used for Import requests
        /// </summary>
        /// <param name="services">Service collection</param>
        private void SetUpHttpClientFactory(IServiceCollection services)
        {
            services.AddHttpClient(
                "TransferClient",
                c =>
                {
                    c.DefaultRequestHeaders.Add("Accept", "application/json");
                })
                .ConfigurePrimaryHttpMessageHandler(() =>
                {
                    var handler = new HttpClientHandler
                    {
                        ClientCertificateOptions = ClientCertificateOption.Manual
                    };
                    handler.ServerCertificateCustomValidationCallback = this.ValidateDestinationCertificate;

                    return handler;
                });
            services.AddHttpClient(
                    "HealthCheckClient",
                    c =>
                    {
                        c.DefaultRequestHeaders.Add("Accept", "application/json");
                    })
                .ConfigurePrimaryHttpMessageHandler(() =>
                {
                    var handler = new HttpClientHandler
                    {
                        ClientCertificateOptions = ClientCertificateOption.Manual
                    };
                    handler.ServerCertificateCustomValidationCallback += this.CertificateValidationCallBack;

                    return handler;
                });
        }

        /// <summary>
        /// Check configuration to see if the system is currently under test.
        /// </summary>
        /// <returns>Return a flag indicating the system is currently under test.</returns>
        private bool RunningInternalTesting()
        {
            return Configuration.GetValue<string>("RunEnv") != null && Configuration.GetValue<string>("RunEnv").Equals("Testing");
        }

        /// <summary>
        /// Validate the certificate attached to the service we are connecting to
        /// </summary>
        /// <param name="request">Http request message</param>
        /// <param name="certificate">Certificate associated with the request</param>
        /// <param name="certificateChain">Certificate change to interrogate</param>
        /// <param name="policy">Secure Socket Layer Policy</param>
        /// <returns>A flag indicating whether the server certificate is valid</returns>
        private bool ValidateDestinationCertificate(HttpRequestMessage request, X509Certificate2 certificate, X509Chain certificateChain, SslPolicyErrors policy)
        {
            Log.Information("Validate Import service certificate");

            if (certificateChain?.ChainStatus != null)
            {
                Log.Information("SSL Policy Chain Not null");

                foreach (var element in certificateChain.ChainElements)
                {
                    Log.Information($"ValidateDestinationCertificate - SSL Policy - Thumbprint - {element.Certificate.Thumbprint}");
                   
                    if (element.Certificate.Thumbprint != null && element.Certificate.Thumbprint.ToLowerInvariant() == Configuration.GetValue<string>("SERVER_CERT_THUMBPRINT").ToLowerInvariant() && element.Certificate.Issuer == Configuration.GetValue<string>("SERVER_CERT_ISSUER"))
                    {
                        Log.Information("ValidateDestinationCertificate - SSL Policy - Chain Element - Returning True");

                        return true;
                    }
                }
            }

            Log.Error("ValidateDestinationCertificate - SSL Policy - Final Exit - Returning False");

            return false;
        }

        /// <summary>
        /// SSL certificate validation callback. Validates connection for any legitimate SSL certificate, self-signed certificates, or AdastraSoftware specific
        /// </summary>
        /// <param name="sender">Sender object requesting validation</param>
        /// <param name="certificate">Certificate to validate</param>
        /// <param name="chain">Chain associated with the certificate</param>
        /// <param name="sslPolicyErrors">SSL policy errors against the certificate</param>
        /// <returns>A flag indicating whether the certificate is deemed valid.</returns>
        private bool CertificateValidationCallBack(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            // If the certificate is a valid, signed certificate, return true.
            if (sslPolicyErrors == SslPolicyErrors.None)
            {
                Log.Information("Certificate Valid");
                return true;
            }

            // If there are errors in the certificate chain, look at each error to determine the cause.
            if ((sslPolicyErrors & SslPolicyErrors.RemoteCertificateChainErrors) != 0)
            {
                Log.Information("SSL Policy Errors in chain");
                return this.ValidateCertificate(certificate, chain);
            }

            // In all other cases, return false.
            return false;
        }

        /// <summary>
        /// A method to validate certificate and look for the exact cause for the certificate error
        /// </summary>
        /// <param name="certificate">Certificate to validate</param>
        /// <param name="chain">Chain associated with the certificate</param>
        /// <returns>A flag indicating whether the certificate is deemed valid.</returns>
        private bool ValidateCertificate(X509Certificate certificate, X509Chain chain)
        {
            if (chain?.ChainStatus != null)
            {
                Log.Information("SSL Policy Chain Not null");

                foreach (var status in chain.ChainStatus)
                {
                    if ((certificate.Subject == certificate.Issuer) &&
                        (status.Status == X509ChainStatusFlags.UntrustedRoot))
                    {
                        Log.Information("SSL Policy Certificate Self-Signed - Valid");
                        //// Self-signed certificates with an untrusted root are valid. 
                    }
                    else
                    {
                        if (status.Status != X509ChainStatusFlags.NoError)
                        {
                            Log.Error($"SSL Policy Certificate Status - Invalid - {status.Status}");

                            //// If there are any other errors in the certificate chain, the certificate is invalid,
                            //// so the method returns false.
                            return false;
                        }
                    }
                }
            }

            // When processing reaches this line, the only errors in the certificate chain are 
            // untrusted root errors for self-signed certificates. So return true.
            return true;
        }
    }
}
