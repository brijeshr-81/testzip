﻿// <copyright file="20211105133506_AddHasOdysseyCore.cs" company="One Advanced">
// Copyright (c) One Advanced. All rights reserved.
// Licensed under the Advanced license.
// </copyright>
namespace AHC.Odyssey.Integration.API.Migrations
{
    using Microsoft.EntityFrameworkCore.Migrations;

    public partial class AddHasOdysseyCore : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "HasOdysseyCore",
                table: "IntegrationMapping",
                defaultValue: true
            );
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "HasOdysseyCore",
                table: "IntegrationMapping"
            );
        }
    }
}
