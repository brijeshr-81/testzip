﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AHC.Odyssey.Integration.API.Migrations
{
    public partial class AddReferrerName : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ReferrerName",
                table: "IntegrationMapping",
                nullable: true,
                defaultValue: "OdysseyED");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ReferrerName",
                table: "IntegrationMapping");
        }
    }
}
