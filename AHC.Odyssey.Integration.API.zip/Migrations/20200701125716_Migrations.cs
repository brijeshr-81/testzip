﻿//-----------------------------------------------------------------------
// <copyright file="20200701125716_Migrations.cs" company="Advanced Health & Care">
//     Copyright © Advanced Health & Care 2020
// </copyright>
//-----------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Migrations
{
    using System;
    using Microsoft.EntityFrameworkCore.Metadata;
    using Microsoft.EntityFrameworkCore.Migrations;

    /// <summary>
    /// Data context migration class
    /// </summary>
    public partial class Migrations : Migration
    {
        /// <summary>
        /// Builds the operations that will migrate the database 'up'.
        /// </summary>
        /// <param name="migrationBuilder">The Microsoft.EntityFrameworkCore.Migrations.MigrationBuilder that will build the operations.</param>
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "IntegrationMapping",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    OdysseyPatientDomainId = table.Column<Guid>(nullable: false),
                    OdysseyCoreDomainId = table.Column<Guid>(nullable: false),
                    OdysseyServiceUrl = table.Column<string>(nullable: false),
                    ThirdPartyData = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_IntegrationMapping", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_IntegrationMapping_OdysseyPatientDomainId",
                table: "IntegrationMapping",
                column: "OdysseyPatientDomainId",
                unique: true);
        }

        /// <summary>
        /// Builds the operations that will migrate the database 'down'.
        /// </summary>
        /// <param name="migrationBuilder">The Microsoft.EntityFrameworkCore.Migrations.MigrationBuilder that will build the operations.</param>
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "IntegrationMapping");
        }
    }
}
