﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="BaseHealthCheck.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API
{
    using System;
    using System.Threading;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Diagnostics.HealthChecks;

    /// <summary>
    /// Base health check class for current domain's import service 
    /// </summary>
    public abstract class BaseHealthCheck : IHealthCheck
    {
        /// <summary>
        /// Http context accessor
        /// </summary>
        private readonly IHttpContextAccessor httpContextAccessor;

        /// <summary>
        /// Initialises an instance of <see cref="BaseHealthCheck"/> class
        /// </summary>
        /// <param name="httpContextAccessor">Http context accessor</param>
        protected BaseHealthCheck(IHttpContextAccessor httpContextAccessor)
        {
            this.httpContextAccessor = httpContextAccessor;
        }

        /// <summary>
        /// Gets the current Domain ID from the request context
        /// </summary>
        protected Guid DomainId
        {
            get
            {
                if (this.httpContextAccessor.HttpContext.Request.Path.HasValue)
                {
                    return Guid.TryParse(this.httpContextAccessor.HttpContext.Request.Path.ToString().Substring(this.httpContextAccessor.HttpContext.Request.Path.ToString().LastIndexOf('/') + 1), out Guid domainId) ?
                    domainId : Guid.Empty;
                }

                return Guid.Empty;
            }
        }

        /// <summary>
        /// Gets a value indicating whether its domain specific health check
        /// </summary>
        protected bool IsDomainSpecific
        {
            get
            {
                return this.httpContextAccessor.HttpContext.Request.Path.HasValue && this.httpContextAccessor.HttpContext.Request.Path.ToString().Contains("domain", StringComparison.InvariantCultureIgnoreCase);
            }
        }

        /// <summary>
        /// Runs the health check, returning the status of the API and any other dependencies
        /// </summary>
        /// <param name="context">A context object associated with the current execution.</param>
        /// <param name="cancellationToken">A System.Threading.CancellationToken that can be used to cancel the health check.</param>
        /// <returns>A Task that completes when the health check has finished</returns>
        public abstract Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default);
    }
}
