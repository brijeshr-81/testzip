﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DatabaseHealthCheck.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API
{
    using System.Threading;
    using System.Threading.Tasks;
    using AHC.Odyssey.Integration.API.DAL;
    using Microsoft.Extensions.Diagnostics.HealthChecks;

    /// <summary>
    /// Health check class for database's status 
    /// </summary>
    public class DatabaseHealthCheck : IHealthCheck
    {
        /// <summary>
        /// Field to hold an instance of Data Context
        /// </summary>
        private readonly IDataContext dataContext;

        /// <summary>
        /// Initialises an instance of <see cref="DatabaseHealthCheck"/> class
        /// </summary>
        /// <param name="dataContext">The data context</param>
        public DatabaseHealthCheck(IDataContext dataContext)
        {
            this.dataContext = dataContext;
        }

        /// <summary>
        /// Runs the health check, returning the status of the API and any other dependencies
        /// Gets the status of database and appends it to the current health checks.
        /// </summary>
        /// <param name="context">A context object associated with the current execution.</param>
        /// <param name="cancellationToken">A System.Threading.CancellationToken that can be used to cancel the health check.</param>
        /// <returns>A Task that completes when the health check has finished, yielding the status of the API and any other dependencies</returns>
        public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = new CancellationToken())
        {
            try
            {
                 return this.dataContext.CanConnect() ? await Task.FromResult(HealthCheckResult.Healthy($"Database is connected.")) : await Task.FromResult(HealthCheckResult.Unhealthy($"Database is not connected."));
            }
            catch
            {
                return await Task.FromResult(HealthCheckResult.Unhealthy($"Database is not connected."));
            }
        }
    }
}
