﻿//-----------------------------------------------------------------------
// <copyright file="IntegrationMapping.cs" company="Advanced Health & Care">
//     Copyright © Advanced Health & Care 2020
// </copyright>
//-----------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.DAL
{
    using System;
    using System.ComponentModel.DataAnnotations;

    /// <summary>
    /// Integration Mapping Model
    /// </summary>
    public class IntegrationMapping
    {
        /// <summary>
        /// Gets or sets Id
        /// </summary>
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets Odyssey Patient Domain Id
        /// </summary>
        [Required]
        public Guid OdysseyPatientDomainId { get; set; }

        /// <summary>
        /// Gets or sets Odyssey Core Domain Id
        /// </summary>
        [Required]
        public Guid OdysseyCoreDomainId { get; set; }

        /// <summary>
        /// Gets or sets Odyssey Service Url
        /// </summary>
        [Required]
        public string OdysseyServiceUrl { get; set; }

        /// <summary>
        /// Gets or sets Third Party reference
        /// </summary>
        public string ThirdPartyData { get; set; }

        /// <summary>
        /// Gets or sets HasOdysseyCore to determine if Adastra is using Odyssey Core
        /// </summary>
        public bool HasOdysseyCore { get; set; }

        /// <summary>
        /// Gets or sets ReferrerName
        /// </summary>
        public string ReferrerName { get; set; }
    }
}
