﻿//-----------------------------------------------------------------------
// <copyright file="IDataContext.cs" company="Advanced Health & Care">
//     Copyright © Advanced Health & Care 2020
// </copyright>
//-----------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.DAL
{
    using Microsoft.EntityFrameworkCore;

    /// <summary>
    /// Contract that defines Data Context
    /// </summary>
    public interface IDataContext 
    {
        /// <summary>
        /// Gets or sets Integration Mapping Details database set
        /// </summary>
        DbSet<IntegrationMapping> IntegrationMapping { get; set; }

        /// <summary>
        /// Function to perform migration
        /// </summary>
        void PerformMigration();

        /// <summary>
        /// Save changes made to Data Context
        /// </summary>
        /// <returns>The number of state entries written to the underlying database.</returns>
        int SaveChanges();

        /// <summary>
        /// Check to see whether the underlying database is available
        /// </summary>
        /// <returns>A flag indicating the database is available and can be connected to</returns>
        bool CanConnect();
    }
}
