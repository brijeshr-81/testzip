﻿//-----------------------------------------------------------------------
// <copyright file="DataContext.cs" company="Advanced Health & Care">
//     Copyright © Advanced Health & Care 2020
// </copyright>
//-----------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.DAL
{
    using System;
    using System.Linq;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;
    using Pomelo.EntityFrameworkCore.MySql.Infrastructure;

    /// <summary>
    /// Class that implements IDataContext interface
    /// </summary>
    public class DataContext : DbContext, IDataContext 
    {
        /// <summary>
        /// Field to hold an instance of <see cref="IConfiguration"/>
        /// </summary>
        protected IConfiguration configuration;

        /// <summary>
        /// Field to hold an instance of <see cref="ILogger"/>
        /// </summary>
        protected ILogger<DataContext> logger;

        /// <summary>
        /// Environment variable for database end point
        /// </summary>
        private const string DB_ENDPOINT_ENV_VAR = "DB_ENDPOINT";

        /// <summary>
        /// Environment variable for database name
        /// </summary>
        private const string DB_NAME_ENV_VAR = "DB_NAME";

        /// <summary>
        /// Environment variable for database user name
        /// </summary>
        private const string DB_USER_ENV_VAR = "DB_USER";

        /// <summary>
        /// Environment variable for database password
        /// </summary>
        private const string DB_PASSWORD_ENV_VAR = "DB_PASSWORD";

        /// <summary>
        /// Initialises an instance of <see cref="DataContext"/> class
        /// </summary>
        /// <param name="sourceLogger">Logger for data context</param>
        /// <param name="sourceConfiguration">application configuration</param>
        public DataContext(ILogger<DataContext> sourceLogger, IConfiguration sourceConfiguration)
        {
            this.logger = sourceLogger;
            this.configuration = sourceConfiguration;
        }

        /// <summary>
        /// Initialises an instance of <see cref="DataContext"/> class
        /// </summary>
        public DataContext()
        {
            //// do nothing
        }

        /// <summary>
        /// Gets or sets Integration Mapping Details database set
        /// </summary>
        public DbSet<IntegrationMapping> IntegrationMapping { get; set; }

        /// <summary>
        /// Function to perform migration
        /// </summary>
        public virtual void PerformMigration()
        {
            try
            {
                this.logger.LogInformation("Database migration initiated");
                Database.Migrate();
                this.logger.LogInformation("Database migration complete");
            }
            catch (Exception e)
            {
                this.logger.LogError(e.ToString());
                throw;
            }
        }

        /// <summary>
        /// Can connect to database
        /// </summary>
        /// <returns>Returns a flag indicating that the Database is available</returns>
        public bool CanConnect()
        {
            return this.Database.CanConnect();
        }

        /// <summary>
        /// configure the database (and other options) to be used for this context. 
        /// This method is called for each instance of the context that is created. 
        /// </summary>
        /// <param name="optionsBuilder">A builder used to create or modify options for this context.</param>
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var databaseEndpoint = this.configuration.GetValue<string>(DB_ENDPOINT_ENV_VAR);
            var databaseName = this.configuration.GetValue<string>(DB_NAME_ENV_VAR);
            var databaseUser = this.configuration.GetValue<string>(DB_USER_ENV_VAR);
            var databasePassword = this.configuration.GetValue<string>(DB_PASSWORD_ENV_VAR);

            if (new[] { databaseEndpoint, databaseName, databaseUser, databasePassword }.Any(string.IsNullOrWhiteSpace))
            {
                var errorMessage =
                    $"The environment variables {DB_ENDPOINT_ENV_VAR} / {DB_NAME_ENV_VAR} / {DB_USER_ENV_VAR} / {DB_PASSWORD_ENV_VAR} have not been set. Unable to start the application.";

                this.logger.LogError(errorMessage);

                throw new InvalidOperationException(errorMessage);
            }

            var connectionString = $"Server={databaseEndpoint};User Id={databaseUser};Password={databasePassword};Database={databaseName};sslmode=none";

            optionsBuilder.UseMySql(
              connectionString, 
                mysqlOptions =>
            {
                mysqlOptions
                .ServerVersion(new Version(5, 7, 29), ServerType.MySql)
                .EnableRetryOnFailure(10, TimeSpan.FromSeconds(15), null);
            });
        }

        /// <summary>
        /// Configure the model that was discovered by convention on your derived context.
        /// </summary>
        /// <param name="modelBuilder">The builder being used to construct the model for this context.</param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Do this first EF works on a last wins basis so if a specific cascade delete is required then add it below here.
            // By default all cascades are turned off.
            foreach (var relationship in modelBuilder.Model.GetEntityTypes().SelectMany(e => e.GetForeignKeys()))
            {
                relationship.DeleteBehavior = DeleteBehavior.Restrict;
            }

            modelBuilder.Entity<IntegrationMapping>();

            this.AddIndexes(modelBuilder);
        }

        /// <summary>
        /// Add index on unique key
        /// </summary>
        /// <param name="modelBuilder">The builder being used to construct the model for this context.</param>
        private void AddIndexes(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<IntegrationMapping>().HasIndex(i => i.OdysseyPatientDomainId).IsUnique();
        }
    }
}
