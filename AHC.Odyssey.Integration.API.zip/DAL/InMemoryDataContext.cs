﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="InMemoryDataContext.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.DAL
{
    using System;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// InMemory data context class.
    /// </summary>
    /// <remarks>Note: Used by Integration Testing only!</remarks>
    public class InMemoryDataContext : DataContext, IDataContext
    {
        /// <summary>
        /// Initialises a new instance of the <see cref="InMemoryDataContext"/> class
        /// </summary>
        /// <param name="sourceLogger">Logging manager</param>
        /// <param name="sourceConfiguration">Configuration manager</param>
        public InMemoryDataContext(ILogger<DataContext> sourceLogger, IConfiguration sourceConfiguration)
        {
            this.logger = sourceLogger;
            this.configuration = sourceConfiguration;
        }

        /// <summary>
        /// Override Perform migration.
        /// </summary>
        public override void PerformMigration()
        {
            // No migration to happen against InMemory database (it's not relational)
        }

        /// <summary>
        /// Override OnConfiguring to specify an InMemory database configuration
        /// </summary>
        /// <param name="optionsBuilder">Database options</param>
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .EnableSensitiveDataLogging();
        }
    }
}
