﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DtoIntegrationMapping.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Models
{
    using System;
    using System.Runtime.Serialization;
    using System.Text.Json.Serialization;
    using System.Text.RegularExpressions;
    using AHC.Odyssey.Integration.API.DAL;

    /// <summary>
    /// Entity to hold mapping details
    /// </summary>
    [DataContract]
    [Serializable]
    public class DtoIntegrationMapping
    {
        /// <summary>
        /// Gets or sets the Odyssey Patient Domain Id.
        /// </summary>
        [DataMember]
        public Guid OdysseyPatientDomainId { get; set; }

        /// <summary>
        /// Gets or sets the Odyssey Core Domain Id.
        /// </summary>
        [DataMember]
        public Guid OdysseyCoreDomainId { get; set; }

        /// <summary>
        /// Gets or sets the Odyssey Service Url.
        /// </summary>
        [DataMember]
        public string OdysseyServiceUrl { get; set; }

        /// <summary>
        /// Gets or sets the Third Party reference.
        /// </summary>
        [DataMember]
        public string ThirdPartyData { get; set; }

        /// <summary>
        /// Get or sets the Has Odyssey Core
        /// </summary>
        [DataMember]
        public bool HasOdysseyCore { get; set; }

        /// <summary>
        /// Get or sets the ReferrerName for the CaseRequest
        /// </summary>
        [DataMember]
        public string ReferrerName { get; set; }

        /// <summary>
        /// Gets a boolean value indicating whether the given object is valid 
        /// </summary>
        /// <returns>Whether the mapping details are valid</returns>
        [JsonIgnore]
        public bool IsValid => this.OdysseyPatientDomainId != Guid.Empty && this.OdysseyCoreDomainId != Guid.Empty &&
                 !string.IsNullOrEmpty(this.OdysseyServiceUrl) && this.IsValidUrl(this.OdysseyServiceUrl) &&
                 !string.IsNullOrEmpty(this.ThirdPartyData) && !string.IsNullOrEmpty(this.ReferrerName);

        /// <summary>
        /// Checks the given model object values is equal to entity object values
        /// </summary>
        /// <param name="source">Entity object</param>
        /// <returns>a boolean value indicating result</returns>
        public bool IsEquals(IntegrationMapping source)
        {
            return this.OdysseyCoreDomainId.Equals(source.OdysseyCoreDomainId) &&
                   this.OdysseyServiceUrl.Equals(source.OdysseyServiceUrl) &&
                   this.HasOdysseyCore.Equals(source.HasOdysseyCore) &&
                   this.ReferrerName.Equals(source.ReferrerName) &&
                   (string.IsNullOrEmpty(this.ThirdPartyData) && string.IsNullOrEmpty(source.ThirdPartyData) ||
                    !string.IsNullOrEmpty(this.ThirdPartyData) && this.ThirdPartyData.Equals(source.ThirdPartyData));
        }

        /// <summary>
        /// Method indicating whether Url is properly formatted
        /// </summary>
        /// <param name="url">url to be check for its format</param>
        /// <returns>a boolean value indicating result</returns>
        private bool IsValidUrl(string url)
        {
            return Regex.IsMatch(url, @"^http(s)?://([\w-]+.)+[\w-]+(/[\w- ./?%&=])?.");
        }
    }
}
