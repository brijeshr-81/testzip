﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ScopeRequirement.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API
{
    using System;
    using Microsoft.AspNetCore.Authorization;

    /// <summary>
    /// Authorization requirement using scope
    /// </summary>
    public class ScopeRequirement : IAuthorizationRequirement
    {
        /// <summary>
        /// Initialises a new instance of <see cref="ScopeRequirement"/> class
        /// </summary>
        /// <param name="scope">the scope</param>
        /// <param name="issuer">token issuing authority</param>
        public ScopeRequirement(string scope, string issuer)
        {
            this.Scope = scope ?? throw new ArgumentNullException(nameof(scope));
            this.Issuer = issuer ?? throw new ArgumentNullException(nameof(issuer));
        }

        /// <summary>
        /// Gets or sets the token issuing authority while using Open Id calls
        /// </summary>
        public string Issuer { get; set; }

        /// <summary>
        /// Gets or sets the scope defined against the issuer
        /// </summary>
        public string Scope { get; set; }
    }
}
