// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Program.cs" company="Advanced Health & Care">
//   Copyright � Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API
{
    using System;
    using System.IO;
    using AHC.Odyssey.Integration.API.Services;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;
    using Serilog;

    /// <summary>
    /// Standard API program
    /// </summary>
    public static class Program
    {
        /// <summary>
        /// Standard program entry method
        /// </summary>
        /// <param name="args">Command line arguments</param>
        public static void Main(string[] args)
        {
            var configuration = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile(path: "appsettings.json", optional: false, reloadOnChange: true)
                .AddEnvironmentVariables().Build();
            Log.Logger = new LoggerConfiguration()
                .ReadFrom.Configuration(configuration)
                .CreateLogger();

            try
            {
                var host = CreateHostBuilder(args).Build();

                using (var scope = host.Services.CreateScope())
                {
                    Log.Logger.Information("Configuring Mutual Authentication Service");
                    var services = scope.ServiceProvider;
                    var mutAuth = services.GetRequiredService<IMutualAuthService>();
                    mutAuth.AssignClientCertificate();
                }

                host.Run();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                Log.Logger.Error(ex, "Integration Api failed to start");
            }
        }

        /// <summary>
        /// Creates a host, additional configurations can be set
        /// </summary>
        /// <param name="args">Command line arguments</param>
        /// <returns>A host builder object</returns>
        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                })
            .ConfigureAppConfiguration((hostingContext, config) => { config.AddEnvironmentVariables(); })
            .UseSerilog();
    }
}
