﻿using Newtonsoft.Json.Converters;

namespace AHC.Odyssey.Integration.API.Converters
{
    /// <summary>
    /// Date converter to Adastra
    /// </summary>
    public class AdastraDateConverter : IsoDateTimeConverter
    {
        public AdastraDateConverter()
        {
            DateTimeFormat = "yyyy-MM-dd";
        }
    }
}
