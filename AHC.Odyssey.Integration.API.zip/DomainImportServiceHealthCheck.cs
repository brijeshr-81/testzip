﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DomainImportServiceHealthCheck.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2021
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Threading;
    using System.Threading.Tasks;
    using AHC.Odyssey.Integration.API.DAL;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Diagnostics.HealthChecks;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Health check class to the request domain's import service
    /// </summary>
    public class DomainImportServiceHealthCheck : BaseHealthCheck
    {
        /// <summary>
        /// Field to hold an instance of Data Context
        /// </summary>
        private readonly IDataContext dataContext;

        /// <summary>
        /// Field to hold an instance of Logger
        /// </summary>
        private readonly ILogger<DomainImportServiceHealthCheck> logger;

        /// <summary>
        /// HttpClient factory
        /// </summary>
        private readonly IHttpClientFactory clientFactory;

        /// <summary>
        /// Initialises an instance of <see cref="DomainImportServiceHealthCheck"/> class
        /// </summary>
        /// <param name="dataContext">The data context</param>
        /// <param name="httpContextAccessor">The http context accessor</param>
        /// <param name="logger">The logger</param>
        /// <param name="factory">The httpClient factory</param>
        public DomainImportServiceHealthCheck(IDataContext dataContext, IHttpContextAccessor httpContextAccessor, ILogger<DomainImportServiceHealthCheck> logger, IHttpClientFactory factory) : base(httpContextAccessor)
        {
            this.dataContext = dataContext;
            this.logger = logger;
            this.clientFactory = factory;
        }

        /// <summary>
        /// Runs the health check, returning the status of the API and any other dependencies
        /// Gets the status of Import Service and appends it to the current health checks.
        /// </summary>
        /// <param name="context">A context object associated with the current execution.</param>
        /// <param name="cancellationToken">A System.Threading.CancellationToken that can be used to cancel the health check.</param>
        /// <returns>A Task that completes when the health check has finished, yielding the status of the API and any other dependencies</returns>
        public override async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = new CancellationToken())
        {
           return this.IsDomainSpecific ? await this.GetDomainHealthCheck() : await this.GetGenericHealthCheck();
        }

        /// <summary>
        /// Provide the health check endpoint for the given site url
        /// </summary>
        /// <param name="sourceUrl">Source Url</param>
        /// <returns>HealthCheck endpoint</returns>
        private static string GetHealthCheckUrl(string sourceUrl)
        {
            if (!sourceUrl.EndsWith("/"))
            {
                sourceUrl += "/";
            }

            return $"{sourceUrl}HealthCheck";
        }

        /// <summary>
        /// Checks if import service for the given domain is healthy
        /// </summary>
        /// <param name="healthCheckUrl">the domain's import service health check url</param>
        /// <returns>a boolean value indicating if the service is healthy</returns>
        private async Task<bool> IsImportServiceHealthy(string healthCheckUrl)
        {
            var client = this.clientFactory.CreateClient("HealthCheckClient");
            var result = await client.GetAsync(new Uri(healthCheckUrl));

            var jsonContent = result.Content.ReadAsStringAsync();
            if (result.StatusCode.Equals(HttpStatusCode.OK) && !jsonContent.Result.Contains("Unhealthy"))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Gets the domain health check for the given domain Id
        /// </summary>
        /// <returns>A Task that completes when the health check has finished, yielding the status of the API and any other dependencies</returns>
        private async Task<HealthCheckResult> GetDomainHealthCheck()
        {
            try
            {
                if (this.DomainId.Equals(Guid.Empty))
                {
                    return await Task.FromResult(HealthCheckResult.Unhealthy($"Import Service is Unhealthy."));
                }

                var dataEntity = this.dataContext.IntegrationMapping.FirstOrDefault(i => i.OdysseyPatientDomainId.Equals(this.DomainId));

                if (dataEntity == null || string.IsNullOrEmpty(dataEntity.OdysseyServiceUrl))
                {
                    return await Task.FromResult(HealthCheckResult.Unhealthy($"Import Service is Unhealthy."));
                }

                var isImportServiceHealthy = await this.IsImportServiceHealthy(GetHealthCheckUrl(dataEntity.OdysseyServiceUrl));
                if (isImportServiceHealthy)
                {
                    this.logger.LogInformation($"{dataEntity.OdysseyServiceUrl} - Successful");
                    return await Task.FromResult(HealthCheckResult.Healthy($"Import Service is healthy."));
                }
                else
                {
                    this.logger.LogError($"{dataEntity.OdysseyServiceUrl} - Failed");
                    return await Task.FromResult(HealthCheckResult.Unhealthy($"Import Service is Unhealthy."));
                }
            }
            catch (Exception e)
            {
                this.logger.LogError(e, $"Domain HealthCheck");
                return await Task.FromResult(HealthCheckResult.Unhealthy($"Import Service is Unhealthy."));
            }
        }

        /// <summary>
        /// Gets the domain health check for all the import services in integration mapping table
        /// </summary>
        /// <returns>A Task that completes when the health check has finished, yielding the status of the API and any other dependencies</returns>
        private async Task<HealthCheckResult> GetGenericHealthCheck()
        {
            var importServiceList = new Dictionary<string, object>();

            if (!this.dataContext.IntegrationMapping.Any())
            {
                return await Task.FromResult(HealthCheckResult.Healthy($"Import Service has no entries.", importServiceList));
            }

            var unhealthyImportServiceList = new List<IntegrationMapping>();

            foreach (var dataEntity in this.dataContext.IntegrationMapping)
            {
                string importServiceStatus;
                try
                {
                    if (dataEntity != null && !string.IsNullOrEmpty(dataEntity.OdysseyServiceUrl))
                    {
                        var isImportServiceHealthy = await this.IsImportServiceHealthy(GetHealthCheckUrl(dataEntity.OdysseyServiceUrl));
                        importServiceStatus = isImportServiceHealthy ? "Healthy" : "Unhealthy";
                        if (!isImportServiceHealthy)
                        {
                            unhealthyImportServiceList.Add(dataEntity);
                        }
                    }
                    else
                    {
                        importServiceStatus = "Unhealthy";
                        unhealthyImportServiceList.Add(dataEntity);
                    }
                }
                catch (Exception e)
                {
                    this.logger.LogError(e, $"Generic HealthCheck - {dataEntity?.OdysseyServiceUrl}");

                    importServiceStatus = "Unhealthy";
                    unhealthyImportServiceList.Add(dataEntity);
                }

                importServiceList.Add(dataEntity?.Id.ToString(), importServiceStatus);
            }

            if (unhealthyImportServiceList.Any())
            { 
                return await Task.FromResult(HealthCheckResult.Degraded($"Import Service is Degraded.", exception: null, importServiceList));
            }

            return await Task.FromResult(HealthCheckResult.Healthy($"Import Service is Healthy.", importServiceList));
        }
    }
}
