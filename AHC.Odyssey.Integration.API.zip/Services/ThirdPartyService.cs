﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ThirdPartyServices.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2021
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Services
{
    using System;
    using System.Net;
    using System.Net.Http;
    using System.Text;
    using AHC.Odyssey.Integration.API.Helpers;
    using AHC.Odyssey.Integration.API.Models;
    using AHC.Odyssey.Integration.API.ThirdParty;
    using AHC.Odyssey.Integration.API.ThirdParty.Adastra;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Third Party assessment submission service
    /// </summary>
    public class ThirdPartyServices : IThirdPartyService
    {
        /// <summary>
        /// Third party Endpoint
        /// </summary>
        private const string SETTINGS_ENDPOINT = "Endpoint";

        /// <summary>
        /// Authorization Endpoint
        /// </summary>
        private const string SETTINGS_AUTH_ENDPOINT = "AuthEndpoint";

        /// <summary>
        /// User name
        /// </summary>
        private const string SETTINGS_USERNAME = "Username";

        /// <summary>
        /// User password
        /// </summary>
        private const string SETTINGS_PASSWORD = "Password";

        /// <summary>
        /// Logging framework
        /// </summary>
        private readonly ILogger<ThirdPartyServices> logger;

        /// <summary>
        /// Initialises a new instance of the <see cref="ThirdPartyServices"/> provided with Logging framework 
        /// </summary>
        /// <param name="logger">Logging framework</param>
        public ThirdPartyServices(ILogger<ThirdPartyServices> logger)
        {
            this.logger = logger;
            this.logger.LogInformation("Third Party service initiated");
        }

        /// <summary>
        /// Gets or sets the Follow Up session Id
        /// </summary>
        public string FollowUpSessionId
        {
            get; set;
        }

        /// <summary>
        /// Gets or sets the Third Party Data
        /// </summary>
        public ThirdPartyData ThirdPartyData
        {
            get; set;
        }

        /// <summary>
        /// Send the assessment details to Third Party
        /// </summary>
        /// <param name="assessmentDetails">The assessment details</param>
        /// <param name="transactionId"> unique transaction id</param>
        /// <param name="referrerName">Referrer Name to send with the CaseRequest</param>
        /// <returns>a value indicating whether the assessment details were successfully submitted to the third party service</returns>
        public bool SendAssessmentToThirdParty(IFormCollection assessmentDetails, Guid transactionId, string referrerName)
        {
            this.logger.LogDebug($"[{transactionId}] - Entering SendAssessmentToThirdParty");
            return this.IsAssessmentSubmitted(assessmentDetails, transactionId, referrerName);
        }

        /// <summary>
        /// Checks if the third party service has accepted the assessment details submitted
        /// </summary>
        /// <param name="assessmentDetails">The assessment details</param>
        /// <param name="transactionId"> unique transaction id</param>
        /// <param name="referrerName">referrer name</param>
        /// <returns>a boolean value indicating if the service has accepted the submitted assessment details</returns>
        private bool IsAssessmentSubmitted(IFormCollection assessmentDetails, Guid transactionId, string referrerName)
        {
            bool isSubmitted = false;
            string token = null;
            try
            {
                switch (ThirdPartyData.ThirdPartyType)
                {
                    case ThirdPartyTypes.URL:
                        break;
                    case ThirdPartyTypes.Adastra:
                        var thirdPartyAuth = new AdastraAuthentication(this.ThirdPartyData.GetSetting(SETTINGS_AUTH_ENDPOINT), this.ThirdPartyData.GetSetting(SETTINGS_ENDPOINT), this.ThirdPartyData.GetSetting(SETTINGS_USERNAME), this.ThirdPartyData.GetSetting(SETTINGS_PASSWORD));
                        token = thirdPartyAuth.GetToken();
                        break;
                    default:
                        return false;
                }

                isSubmitted = this.SendToThirdParty(assessmentDetails, transactionId, referrerName, token);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, $"[{transactionId}] - Exception : {ex.Message} while submitting assesment to {this.ThirdPartyData.GetSetting(SETTINGS_ENDPOINT)}.");
            }

            return isSubmitted;
        }

        /// <summary>
        /// Send assessment to third party
        /// </summary>
        /// <param name="assessmentDetails">The assessment details</param>
        /// <param name="transactionId">unique transaction id</param>
        /// <param name="referrerName">referrer name</param>
        /// <param name="token">token to be added to header as bearer</param>
        /// <returns>a boolean value indicating if assessment is sent to the third party</returns>
        private bool SendToThirdParty(IFormCollection assessmentDetails, Guid transactionId, string referrerName,  string token = null)
        {
            bool isSubmitted = false;
            HttpResponseMessage result;

            var jsonStructure = this.GenerateJsonStructure(assessmentDetails, referrerName);
            this.logger.LogInformation($"JSON Data - {jsonStructure }");

            using (var httpClient = new HttpClient())
            {
                if (!string.IsNullOrEmpty(token))
                {
                    httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
                }

                httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                var data = new StringContent(jsonStructure, Encoding.UTF8, "application/json");

                var message = new HttpRequestMessage
                {
                    Method = HttpMethod.Post,
                    RequestUri = new Uri(this.ThirdPartyData.GetSetting(SETTINGS_ENDPOINT)),
                    Content = data
                };

                result = httpClient.SendAsync(message).Result;
            }

            if (result.StatusCode.Equals(HttpStatusCode.Created))
            {
                isSubmitted = true;
            }
            else
            {
                this.logger.LogError($"[{transactionId}] - {result.StatusCode} : Failed to submit assesment details to {this.ThirdPartyData.GetSetting(SETTINGS_ENDPOINT)}.");
            }

            return isSubmitted;
        }

        /// <summary>
        /// Get JSON profile to be submitted to the third party
        /// </summary>
        /// <param name="assessmentDetails">The assessment details</param>
        /// <param name="referrerName">referrer name</param>
        /// <returns>A JSON profile</returns>
        private string GenerateJsonStructure(IFormCollection assessmentDetails, string referrerName)
        {
            PatientDateOfBirth dateOfBirth = null;
            var outcomeCode = assessmentDetails["Assessment.Urgency"];
            var relativeUrgency = RelativeUrgency.ToAdastraUrgency(outcomeCode);
            var returnPhone = assessmentDetails["Patient.CallbackNumber"];
            var symptoms = assessmentDetails["Assessment.Complaint"];
            var currentLocationAddress = new Models.Address(); //No data required from Odyssey
            if (!string.IsNullOrEmpty(assessmentDetails["Patient.ApproximateAge"]) && !bool.Parse(assessmentDetails["Patient.ApproximateAge"]))
            {
                dateOfBirth = new PatientDateOfBirth(DateTime.Parse(assessmentDetails["Patient.DateOfBirth"]), false);
            }
            else
            {
                dateOfBirth = new PatientDateOfBirth(DateTime.UtcNow.AddDays(-(int.Parse(assessmentDetails["Patient.Age"]) * 7)), true);
            }

            var patient = new Patient() 
            {
                Forename = assessmentDetails["Patient.Forename"],
                Surname = assessmentDetails["Patient.Surname"],
                Sex = Enum.Parse<Patient.SexEnum>(assessmentDetails["Patient.Gender"] == "M" ? "Male" : "Female"),
                DateOfBirth = dateOfBirth
            };

            var referrer = new Referrer(!string.IsNullOrEmpty(referrerName) ? referrerName : "OdysseyED")
            {
                Reference = new ReferrerReference() { CaseId = assessmentDetails["Assessment.ReferenceNumber"] }
            };

            var odysseyTriage = new OdysseyTriage(this.FollowUpSessionId, assessmentDetails["Assessment.ClientVersion"], assessmentDetails["Assessment.ClinicalVersion"], assessmentDetails["Assessment.Urgency"], int.Parse(assessmentDetails["Patient.Age"]), assessmentDetails["Assessment.XmlData"]);

            var caseRequest = new CaseRequest(outcomeCode, relativeUrgency, returnPhone, symptoms, currentLocationAddress, patient, referrer, odysseyTriage);

            return caseRequest.ToJson();
        }
    }
}
