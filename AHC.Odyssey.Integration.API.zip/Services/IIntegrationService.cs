﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IIntegrationService.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Services
{
    using System;
    using System.Collections.Generic;
    using AHC.Odyssey.Integration.API.Models;

    /// <summary>
    /// Contract for integration service
    /// </summary>
    public interface IIntegrationService
    {
        /// <summary>
        /// Function to create/add a new integration mapping
        /// </summary>
        /// <param name="mappingDetails">The mapping details to be saved</param>
        /// <returns>Id of the updated database record</returns>
        int AddMapping(DtoIntegrationMapping mappingDetails);

        /// <summary>
        /// Function to get an integration mapping for a given Odyssey Patient domain Id
        /// </summary>
        /// <param name="odysseyPatientDomainId">The odyssey patient domain Id for which mapping is to be retrieved</param>
        /// <returns>Matching mapping details</returns>
        DtoIntegrationMapping GetMappingByOdysseyPatientId(Guid odysseyPatientDomainId);

        /// <summary>
        /// Function to update a integration mapping
        /// </summary>
        /// <param name="mappingDetails">The mapping details to be update</param>
        /// <param name="alreadyUpdated">boolean value to indicate record is already updated</param>
        /// <returns>Id of the updated database record</returns>
        int UpdateMapping(DtoIntegrationMapping mappingDetails, out bool alreadyUpdated);

        /// <summary>
        /// Function to get all mapping details
        /// </summary>
        /// <returns>List of all mapping details</returns>
        List<DtoIntegrationMapping> GetAllMapping();
    }
}
