﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MutualAuthService.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2021
// </copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace AHC.Odyssey.Integration.API.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Cryptography.X509Certificates;
    using AHC.Odyssey.Integration.API.Responses;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;
    using Newtonsoft.Json;

    /// <summary>
    /// Mutual authentication service
    /// </summary>
    public class MutualAuthService : IMutualAuthService
    {
        /// <summary>
        /// Logging framework
        /// </summary>
        private readonly ILogger<MutualAuthService> logger;

        /// <summary>
        /// Configuration provider
        /// </summary>
        private readonly IConfiguration configuration;

        /// <summary>
        /// Client side certificate used by the Integration Service for Mutual Authentication
        /// </summary>
        private X509Certificate2 clientCertificate;

        /// <summary>
        /// Instantiates a new instance of the <see cref="MutualAuthService"/> class
        /// </summary>
        /// <param name="logger">Logging framework from IoC</param>
        /// <param name="configuration">Configuration provider</param>
        public MutualAuthService(ILogger<MutualAuthService> logger, IConfiguration configuration)
        {
            this.logger = logger;
            this.logger.LogInformation("Mutual Authentication service initiated");

            this.configuration = configuration;
        }

        /// <summary>
        /// Assign the Client certificate to the Mutual Authentication Service
        /// </summary>
        public void AssignClientCertificate()
        {
            var certificateFile = this.configuration.GetValue<string>("CLIENT_CERT_FILE");
            var certificatePwd = this.configuration.GetValue<string>("CLIENT_CERT_PASSWORD");

            if (new[] { certificateFile, certificatePwd }.Any(string.IsNullOrWhiteSpace))
            {
                var errorMessage = "The environment variables CLIENT_CERT_FILE or CLIENT_CERT_PASSWORD have not been set. Unable to start the application.";
                this.logger.LogError(errorMessage);

                throw new InvalidOperationException(errorMessage);
            }

            this.logger.LogInformation($"Creating certificate from file: {certificateFile}");

            try
            {
                this.logger.LogInformation($"Performing build certificate Started");
                var certificate = new X509Certificate2(certificateFile, "transmit", X509KeyStorageFlags.Exportable);
                this.logger.LogInformation($"Performing build certificate Complete");

                if (!this.ClientCertificateValid(certificate))
                {
                    throw new InvalidOperationException("Mutual autentication Client certificate cannot be assigned.");
                }

                this.clientCertificate = certificate;
            } 
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Error Building Certificate.");
            }
        }

        /// <summary>
        /// Get the client side certificate for use in mutual authentication
        /// </summary>
        /// <returns>Client side certificate</returns>
        public X509Certificate2 GetClientCertificate()
        {
            if (this.clientCertificate == null)
            {
                this.logger.LogError("Mutual Authentication Client certificate not assigned. Call AssignClientCertificate with a legitimate certificate before calling this method.");
                throw new InvalidOperationException("Mutual Authentication Client certificate not assigned");
            }

            return this.clientCertificate;
        }

        /// <summary>
        /// Provide the encrypted request key used as part of the mutual authentication
        /// </summary>
        /// <param name="destinationDomain">Target domain identifier</param>
        /// <param name="thumbprint">Certificate thumbprint</param>
        /// <returns>Encrypted request string</returns>
        public string GetRequestKey(Guid destinationDomain, string thumbprint)
        {
            var requestKeys = new Dictionary<string, string>()
            {
                { "domainId", destinationDomain.ToString() },
                { "thumbprint", thumbprint },
                { "dateTime", DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss") }
            };

            var keyString = JsonConvert.SerializeObject(requestKeys);

            var saltKey = "ThisIsTheSaltKey";

            var encryptedResult = Helpers.RijndaelManagedEncryption.EncryptRijndael(keyString, saltKey);

            return encryptedResult;
        }

        /// <summary>
        /// Validate the Client Certificate
        /// </summary>
        /// <param name="certificate">Client certificate</param>
        /// <returns>A flag indicating whether the certificate is valid, or not.</returns>
        private bool ClientCertificateValid(X509Certificate2 certificate)
        {
            var response = this.ValidateCertificate(certificate);
            if (!response.IsValid)
            {
                this.logger.LogError(response.Text);
            }

            return response.IsValid;
        }

        /// <summary>
        /// Carry out standard validation against the provided certificate
        /// </summary>
        /// <param name="certificate">Certificate subjected to the validation</param>
        /// <returns>A <see cref="MessageResponse"/> indicating whether the certificate is valid, or not together with reasoning.</returns>
        private MessageResponse ValidateCertificate(X509Certificate2 certificate)
        {
            if (DateTime.Parse(certificate.GetEffectiveDateString()) > DateTime.UtcNow)
            {
                return new MessageResponse { IsValid = false, Text = "The certificate supplied is not valid. It's effective date is in the future" };
            }

            if (DateTime.Parse(certificate.GetExpirationDateString()) <= DateTime.UtcNow)
            {
                return new MessageResponse { IsValid = false, Text = "The certificate supplied is not valid. It has expired" };
            }

            if (string.IsNullOrEmpty(this.configuration.GetValue<string>("CertificateIssuer")) || !certificate.Issuer.Equals(this.configuration.GetValue<string>("CertificateIssuer")))
            {
                var errorMessage = "The certificate supplied is not by a trusted root.";
                throw new InvalidOperationException(errorMessage);
            }

            return new MessageResponse { IsValid = true, Text = "The certificate supplied is valid." };
        }
    }
}
