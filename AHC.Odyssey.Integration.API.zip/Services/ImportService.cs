﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ImportService.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Services
{
    using System;
    using System.IO;
    using System.Net.Http;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Import service class
    /// </summary>
    public class ImportService : IImportService
    {
        /// <summary>
        /// Logging framework
        /// </summary>
        private readonly ILogger<ImportService> logger;

        /// <summary>
        /// Mutual authentication service
        /// </summary>
        private readonly IMutualAuthService mutualAuthService;

        /// <summary>
        /// HttpClient factory
        /// </summary>
        private readonly IHttpClientFactory clientFactory;

        /// <summary>
        /// Initialises a new instance of the <see cref="ImportService"/> using provided Logging framework and mutual authentication service
        /// </summary>
        /// <param name="logger">Logging framework</param>
        /// <param name="mutualAuth">Mutual Authentication Service</param>
        /// <param name="factory">HttpClient factory for requests</param>
        public ImportService(ILogger<ImportService> logger, IMutualAuthService mutualAuth, IHttpClientFactory factory)
        {
            this.logger = logger;
            this.mutualAuthService = mutualAuth;
            this.clientFactory = factory;
            this.logger.LogInformation("Import service initiated");
        }

        /// <summary>
        /// Instantiates a new instance of the <see cref="ImportService"/>
        /// </summary>
        protected ImportService()
        {
        }

        /// <summary>
        /// Method to transfer data to the Import API
        /// </summary>
        /// <param name="odysseyCoreDomainId">Odyssey Core Domain Id</param>
        /// <param name="importServiceUrl">Import service url</param>
        /// <param name="formFile">Form File</param>
        /// <param name="transactionId">uniquetransaction id</param>
        /// <returns>Https code of the request</returns>
        public HttpResponseMessage TransferData(Guid odysseyCoreDomainId, string importServiceUrl, IFormFile formFile, Guid transactionId)
        {
            this.logger.LogDebug($"[{transactionId}] - Entering TransferData [OdysseyCoreDomainId {odysseyCoreDomainId}, ImportBaseUrl {importServiceUrl}]");
            try
            {
                // Information coming in.
                byte[] fileArray;
                using (var memoryStream = new MemoryStream())
                {
                    formFile.CopyTo(memoryStream);
                    fileArray = memoryStream.ToArray();
                }

                // Information going out.
                var client = this.clientFactory.CreateClient("TransferClient");

                client.DefaultRequestHeaders.Add("X-ARR-ClientCert", Convert.ToBase64String(this.mutualAuthService.GetClientCertificate().Export(System.Security.Cryptography.X509Certificates.X509ContentType.Pkcs12)));
                client.DefaultRequestHeaders.Add("X-ADV-RequestKey", this.mutualAuthService.GetRequestKey(odysseyCoreDomainId, this.mutualAuthService.GetClientCertificate().Thumbprint));
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/zip"));

                var message = new HttpRequestMessage
                {
                    Method = HttpMethod.Post,
                    RequestUri = new Uri($"{importServiceUrl}/ImportData/{odysseyCoreDomainId}")
                };

                using var formData = new MultipartFormDataContent
                {
                    { new ByteArrayContent(fileArray), formFile.Name, formFile.FileName },
                    { new StringContent(transactionId.ToString()), "transactionId" }
                };

                message.Content = formData;
                return client.SendAsync(message).Result;
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, $"[{transactionId}] - Exception:{ex.Message} for transfer the data to {importServiceUrl}");
                throw new InvalidOperationException("Failed to transfer the data");
            }
        }
    }
}
