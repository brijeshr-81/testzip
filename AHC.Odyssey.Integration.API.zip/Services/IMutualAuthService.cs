﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IMutualAuthService.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace AHC.Odyssey.Integration.API.Services
{
    using System;
    using System.Security.Cryptography.X509Certificates;

    /// <summary>
    /// Interface for mutual authentication service
    /// </summary>
    public interface IMutualAuthService
    {
        /// <summary>
        /// Assign the Client certificate to the Mutual Authentication Service
        /// </summary>
        void AssignClientCertificate();

        /// <summary>
        /// Get the client side certificate for use in mutual authentication
        /// </summary>
        /// <returns>Client side certificate</returns>
        X509Certificate2 GetClientCertificate();

        /// <summary>
        /// Generate the request key using the provided information
        /// </summary>
        /// <param name="destinationDomain">Core domain identifier</param>
        /// <param name="thumbprint">Certificate thumbprint</param>
        /// <returns>Request key string</returns>
        string GetRequestKey(Guid destinationDomain, string thumbprint);
    }
}
