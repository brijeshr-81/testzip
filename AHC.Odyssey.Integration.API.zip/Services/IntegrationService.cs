﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IntegrationService.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AHC.Odyssey.Integration.API.DAL;
    using AHC.Odyssey.Integration.API.Models;
    using AutoMapper;
    using Microsoft.Extensions.Logging;
    using Newtonsoft.Json;

    /// <summary>
    /// Class that implements the <see cref="IIntegrationService"/> interface
    /// </summary>
    public class IntegrationService : IIntegrationService
    {
        /// <summary>
        /// Field to hold data context instance
        /// </summary>
        private readonly IDataContext dataContext;

        /// <summary>
        /// Field to hold the mapper instance
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// Field to hold logger object
        /// </summary>
        private readonly ILogger<IntegrationService> logger;

        /// <summary>
        /// Initialises an instance of <see cref="IntegrationService"/> class
        /// </summary>
        /// <param name="dataContext">The data context</param>
        /// <param name="mapper">The mapper</param>
        /// <param name="logger">The logger</param>
        public IntegrationService(IDataContext dataContext, IMapper mapper, ILogger<IntegrationService> logger)
        {
            this.dataContext = dataContext;
            this.mapper = mapper;
            this.logger = logger;
        }

        /// <summary>
        /// Function to create/add a new integration mapping
        /// </summary>
        /// <param name="mappingDetails">The mapping details to be saved</param>
        /// <returns>Id of the updated database record</returns>
        public int AddMapping(DtoIntegrationMapping mappingDetails)
        {
            this.logger.LogDebug($"Entering UpdateMapping [MappingDetails {JsonConvert.SerializeObject(mappingDetails)}]");
            var result = 0;

            try
            {
                if (this.dataContext.IntegrationMapping.Any(m => m.OdysseyPatientDomainId.Equals(mappingDetails.OdysseyPatientDomainId)))
                {
                    return 0;
                }

                var dataEntity = this.mapper.Map<IntegrationMapping>(mappingDetails);
                this.dataContext.IntegrationMapping.Add(dataEntity);
                result = this.dataContext.SaveChanges();
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, $"Exception:{ex.Message} for mapping record {JsonConvert.SerializeObject(mappingDetails)}");
                throw;
            }

            this.logger.LogDebug($"Exiting UpdateMapping [MappingDetails {JsonConvert.SerializeObject(mappingDetails)}]");

            return result;
        }

        /// <summary>
        /// Function to get an integration mapping for a given Odyssey Patient domain Id
        /// </summary>
        /// <param name="odysseyPatientDomainId">The odyssey patient domain Id for which mapping is to be retrieved</param>
        /// <returns>Matching mapping details</returns>
        public DtoIntegrationMapping GetMappingByOdysseyPatientId(Guid odysseyPatientDomainId)
        {
            this.logger.LogDebug($"Entering GetMappingByOdysseyPatientId [OdysseyPatientId {odysseyPatientDomainId}]");
            DtoIntegrationMapping mapping = null;

            try
            {
                var dataEntity = this.dataContext.IntegrationMapping.FirstOrDefault(i => i.OdysseyPatientDomainId.Equals(odysseyPatientDomainId));

                if (dataEntity != null)
                {
                    mapping = this.mapper.Map<DtoIntegrationMapping>(dataEntity);
                }
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, $"Exception:{ex.Message} while retrieving mapping record for OdysseyPatientId {odysseyPatientDomainId}");
                throw;
            }

            this.logger.LogDebug($"Exiting GetMappingByOdysseyPatientId [OdysseyPatientId {odysseyPatientDomainId}]");

            return mapping;
        }

        /// <summary>
        /// Function to update a integration mapping
        /// </summary>
        /// <param name="mappingDetails">The mapping details to be update</param>
        /// <param name="alreadyUpdated">boolean value to indicate record is already updated</param> 
        /// <returns>Id of the updated database record</returns>
        public int UpdateMapping(DtoIntegrationMapping mappingDetails, out bool alreadyUpdated)
        {
            this.logger.LogDebug($"Entering UpdateMapping [MappingDetails {JsonConvert.SerializeObject(mappingDetails)}]");
            var result = 0;
            
            try
            {
                var dataEntity = this.dataContext.IntegrationMapping.FirstOrDefault(m =>
                    m.OdysseyPatientDomainId.Equals(mappingDetails.OdysseyPatientDomainId));
                alreadyUpdated = dataEntity != null && mappingDetails.IsEquals(dataEntity);
                if (dataEntity != null && !alreadyUpdated)
                {
                    this.mapper.Map(mappingDetails, dataEntity);
                    result = this.dataContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, $"Exception:{ex.Message} for mapping record {JsonConvert.SerializeObject(mappingDetails)}");
                throw;
            }

            this.logger.LogDebug($"Exiting UpdateMapping [MappingDetails {JsonConvert.SerializeObject(mappingDetails)}]");
            return result;
        }

        /// <summary>
        /// Function to get all mapping details
        /// </summary>
        /// <returns>List of all mapping details</returns>
        public List<DtoIntegrationMapping> GetAllMapping()
        {
            this.logger.LogDebug("Entering GetAllMapping");
            List<DtoIntegrationMapping> allMapping = null;

            try
            {
                var mappingList = this.dataContext.IntegrationMapping.ToList();

                if (mappingList.Any())
                {
                    allMapping = new List<DtoIntegrationMapping>();
                    foreach (var mapping in mappingList)
                    {
                        allMapping.Add(this.mapper.Map<DtoIntegrationMapping>(mapping));
                    }
                }
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, $"Exception:{ex.Message} while retrieving mapping deatils.");
                throw;
            }

            this.logger.LogDebug("Exiting GetAllMapping");

            return allMapping;
        }
    }
}
