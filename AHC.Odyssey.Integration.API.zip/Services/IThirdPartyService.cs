﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IThirdPartyService.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Services
{
    using System;
    using AHC.Odyssey.Integration.API.ThirdParty;
    using Microsoft.AspNetCore.Http;

    /// <summary>
    /// Interface for Third Party assessment submission service
    /// </summary>
    public interface IThirdPartyService
    {
        /// <summary>
        /// Gets or sets the Follow Up session Id
        /// </summary>
        string FollowUpSessionId
        {
            get; set;
        }

        /// <summary>
        /// Gets or sets the Third Party Service Url
        /// </summary>
        ThirdPartyData ThirdPartyData
        {
            get; set;
        }

        /// <summary>
        /// Send the assessment details to Third Party
        /// </summary>
        /// <param name="assessmentDetails">The assessment details</param>
        /// <param name="transactionId"> unique transaction id</param>
        /// <param name="referrerName">Referrer Name to send with the CaseRequest</param>
        /// <returns>a value indicating whether the assessment details were successfully submitted to the third party service</returns>
        bool SendAssessmentToThirdParty(IFormCollection assessmentDetails, Guid transactionId, string referrerName);
    }
}
