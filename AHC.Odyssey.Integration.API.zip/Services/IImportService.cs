﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IImportService.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Services
{
    using System;
    using System.Net.Http;
    using Microsoft.AspNetCore.Http;

    /// <summary>
    /// IImportService Interface
    /// </summary>
    public interface IImportService
    {
        /// <summary>
        /// Method to transfer data to the Import API
        /// </summary>
        /// <param name="odysseyCoreDomainId">Odyssey Core Domain Id</param>
        /// <param name="importServiceUrl">import service url</param>
        /// <param name="formFile">Form File</param>
        /// <param name="transactionId"> unique transaction id</param>
        /// <returns>return status code</returns>
        HttpResponseMessage TransferData(Guid odysseyCoreDomainId, string importServiceUrl, IFormFile formFile, Guid transactionId);
    }
}
