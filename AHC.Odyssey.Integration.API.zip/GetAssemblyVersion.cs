﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="GetAssemblyVersion.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API
{
    using System.Threading;
    using System.Threading.Tasks;
    using Microsoft.Extensions.Diagnostics.HealthChecks;

    /// <summary>
    /// Health Check class to get Assembly Version
    /// </summary>
    public class GetAssemblyVersion : IHealthCheck
    {
        /// <summary>
        /// Runs the health check, returning the status of the API and any other dependencies
        /// Gets the version of the currently deployed application and appends it to the current health checks.
        /// </summary>
        /// <param name="context">A context object associated with the current execution.</param>
        /// <param name="cancellationToken">A System.Threading.CancellationToken that can be used to cancel the health check.</param>
        /// <returns>A Task that completes when the health check has finished, yielding the status of the API and any other dependencies</returns>
        public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
        {
            var versionNumber = GetType().Assembly.GetName().Version.ToString();
            return await Task.FromResult(HealthCheckResult.Healthy($"Assembly Version : {versionNumber}"));
        }
    }
}
