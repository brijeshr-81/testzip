﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MapperHelper.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Mappers
{
    using System;
    using AutoMapper;

    /// <summary>
    /// Helper class for mapping objects
    /// </summary>
    public static class MapperHelper
    {
        /// <summary>
        /// The lock object
        /// </summary>
        private static readonly object LockObject = new object();

        /// <summary>
        /// Gets a collection of Mapper profile types
        /// </summary>
        public static Type[] MapperProfileTypes { get; } = { typeof(IntegrationMapperProfile) };

        /// <summary>
        /// Create Mapping for defined profiles
        /// </summary>
        /// <returns>Mapper object</returns>
        public static IMapper CreateMapper()
        {
            lock (LockObject)
            {
                var config = new MapperConfiguration(cfg =>
                {
                    cfg.AddProfiles(new Profile[]
                    {
                    new IntegrationMapperProfile()
                    });
                });

                config.CompileMappings();

                return config.CreateMapper();
            }
        }
    }
}
