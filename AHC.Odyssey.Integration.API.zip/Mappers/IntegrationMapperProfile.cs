﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IntegrationMapperProfile.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Mappers
{
    using AHC.Odyssey.Integration.API.DAL;
    using AHC.Odyssey.Integration.API.Models;
    using AutoMapper;

    /// <summary>
    /// Mapper profile for integration mapping
    /// </summary>
    public class IntegrationMapperProfile : Profile
    {
        /// <summary>
        /// Initialises an instance of <see cref="IntegrationMapperProfile"/> class
        /// </summary>
        public IntegrationMapperProfile()
        {
            CreateMap<IntegrationMapping, DtoIntegrationMapping>().ReverseMap();
        }
    }
}
