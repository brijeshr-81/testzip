﻿using Newtonsoft.Json.Linq;
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace AHC.Odyssey.Integration.API.ThirdParty.Adastra
{
    /// <summary>
    /// AdastraAuthentication to retrieve token from Adastra
    /// </summary>
    public class AdastraAuthentication : ThirdPartyAuthentication
    {
        public string AuthEndpoint { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        public AdastraAuthentication(string authEndpoint, string endpoint, string username, string password)
        {
            this.AuthEndpoint = authEndpoint;
            this.Endpoint = endpoint;
            this.Username = username;
            this.Password = password;
        }

        /// <summary>
        /// Get the Token from Adastra
        /// </summary>
        /// <returns>token or null</returns>
        public override string GetToken()
        {
            HttpResponseMessage result;

            using (var httpClient = new HttpClient())
            {

                httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                var data = new StringContent(GetAuthBody(), Encoding.UTF8, "application/json");

                var authMessage = new HttpRequestMessage
                {
                    Method = HttpMethod.Post,
                    RequestUri = new Uri(this.AuthEndpoint),
                    Content = data
                };

                result = httpClient.SendAsync(authMessage).Result;
            }

            if (result.IsSuccessStatusCode)
            {
                string responseStream = Task.FromResult(result.Content.ReadAsStringAsync()).GetAwaiter().GetResult().Result;

                var token = JToken.Parse(responseStream)["token"].Value<string>();
                return token;
            }
            
            return null;
        }

        /// <summary>
        /// Get the request body using the Username and Password
        /// </summary>
        /// <returns>Username and Password converted to JSON</returns>
        private string GetAuthBody()
        {
            return new AuthCredentials(this.Username, this.Password).ToJson();
        }
    }
}
