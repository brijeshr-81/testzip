﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AdastraUrgent.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2021
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Enums
{
    //IMPORTANT NOTE:
    //      This enum is in reverse order from Odyssey Urgent enum by design
    //      The "None" option MUST be the highest value
    //      This enum is used to collect the relativeUrgency value in the Adastra CaseRequest
    //      Values should NOT be negative
    public enum AdastraUrgent
    {
        /// <summary>
        /// The EMER urgency
        /// </summary>
        EMER = 1,

        /// <summary>
        /// The IMM1 urgency
        /// </summary>
        IMM1 = 2,

        /// <summary>
        /// The IMM2 urgency
        /// </summary>
        IMM2 = 3,

        /// <summary>
        /// The IMM3 urgency
        /// </summary>
        IMM3 = 4,

        /// <summary>
        /// The URG1 urgency
        /// </summary>
        URG1 = 5,

        /// <summary>
        /// THE URG2 urgency
        /// </summary>
        URG2 = 6,

        /// <summary>
        /// The MODE urgency
        /// </summary>
        MODE = 7,

        /// <summary>
        /// The ROUT urgency
        /// </summary>
        ROUT = 8,

        /// <summary>
        /// The NONE urgency
        /// </summary>
        NONE = 9,
    }
}
