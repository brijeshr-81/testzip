﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="RelativeUrgency.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2021
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Helpers
{
    using System;
    using AHC.Odyssey.Integration.API.Enums;
    
    public static class RelativeUrgency
    {
        public static int ToAdastraUrgency(string currentUrgency)
        {
            if (!string.IsNullOrEmpty(currentUrgency) && Enum.IsDefined(typeof(AdastraUrgent), currentUrgency))
            {
                return (int)Enum.Parse(typeof(AdastraUrgent), currentUrgency);
            }

            return -1;
        }
    }
}
