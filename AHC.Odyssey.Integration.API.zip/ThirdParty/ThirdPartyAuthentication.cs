﻿namespace AHC.Odyssey.Integration.API.ThirdParty
{
    /// <summary>
    /// ThirdParty types requiring authentication must ingerit from this class
    /// </summary>
    public abstract class ThirdPartyAuthentication : AuthenticationBase
    {
        public abstract string GetToken();
    }
}
