﻿namespace AHC.Odyssey.Integration.API.ThirdParty
{
    /// <summary>
    /// Authentication base class for ThirdPartyData settings
    /// </summary>
    public abstract class AuthenticationBase
    {
        public string Endpoint { get; set; }

    }
}
