﻿using System.Collections.Generic;
using System.Linq;

namespace AHC.Odyssey.Integration.API.ThirdParty
{
    /// <summary>
    /// Get or Set settings with Type
    /// </summary>
    public class ThirdPartyData
    {
        public Dictionary<string, string> Settings { get; set; } = new Dictionary<string, string>();

        public ThirdPartyTypes ThirdPartyType { get; set; }
        
        /// <summary>
        /// Get a setting from the Settings using a key
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public string GetSetting(string key)
        {
            return (from kvp in Settings where kvp.Key == key select kvp.Value).FirstOrDefault();
        }


        /// <summary>
        /// Add a setting with a type
        /// </summary>
        /// <param name="thirdPartyType">Type of settings</param>
        /// <param name="Settings">Settings for the specified type</param>
        public void AddSetting(ThirdPartyTypes thirdPartyType, Dictionary<string, string> Settings)
        {
            this.ThirdPartyType = thirdPartyType;
            this.Settings = Settings;
        }
    }
}
