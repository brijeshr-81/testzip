﻿namespace AHC.Odyssey.Integration.API.ThirdParty
{
    /// <summary>
    /// Various types of third party types
    ///  - URL - endpoint only
    ///  - Adastra - requires authentication
    /// </summary>
    public enum ThirdPartyTypes
    {
        URL,
        Adastra
    }
}
