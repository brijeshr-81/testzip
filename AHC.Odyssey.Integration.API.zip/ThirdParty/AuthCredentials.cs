﻿using Newtonsoft.Json;

namespace AHC.Odyssey.Integration.API.ThirdParty
{
    /// <summary>
    /// Basic auth credentials
    /// </summary>
    public class AuthCredentials
    {
        public string Username { get; set; }
        public string Password { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="username">Username</param>
        /// <param name="password">Password</param>
        public AuthCredentials(string username, string password)
        {
            this.Username = username;
            this.Password = password;
        }

        /// <summary>
        /// Helper function to convert to Json format
        /// </summary>
        /// <returns>Jaon serialised string of this class</returns>
        public string ToJson()
        {
            return JsonConvert.SerializeObject(this);
        }
    }
    
}
