﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MessageResponse.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace AHC.Odyssey.Integration.API.Responses
{
    /// <summary>
    /// Message response class
    /// </summary>
    public class MessageResponse
    {
        /// <summary>
        /// Gets or sets a value indicating whether this message is in relation to a valid scenario
        /// </summary>
        public bool IsValid { get; set; }

        /// <summary>
        /// Gets or sets the message text
        /// </summary>
        public string Text { get; set; }
    }
}
