﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ContentHelper.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Tests.Helpers
{
    using System.Net.Http;
    using System.Text;
    using Newtonsoft.Json;

    /// <summary>
    /// Static content helper class
    /// </summary>
    public static class ContentHelper
    {
        /// <summary>
        /// Gets the string content from json serialised object
        /// </summary>
        /// <param name="obj">json object</param>
        /// <returns>json serialised string content</returns>
        public static StringContent GetStringContent(object obj)
            => new StringContent(JsonConvert.SerializeObject(obj), Encoding.Default, "application/json");
    }
}
