﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AHC.Odyssey.Integration.API.Tests.Helpers
{
    public static class ThirdPartyDataHelper
    {
        /// <summary>
        /// Gets a smaple of the correctly formatted ThirdPartData
        /// </summary>
        /// <returns></returns>
        public static string GetValidThirdPartyData()
        {
            return "{\"Settings\":{\"AuthEndpoint\":\"https://localhost:44304/api/authenticate\",\"Endpoint\":\"https://localhost:44304/case-requests\",\"Username\":\"AUsername1\",\"Password\":\"APassword1\"},\"thirdPartyType\":1}";
        }

        /// <summary>
        /// Gets a smaple of the missing settings in ThirdPartData
        /// </summary>
        /// <returns></returns>
        public static string GetThirdPartyDataWithMissingSettings()
        {
            return "{\"thirdPartyType\":1}";
        }

        /// <summary>
        /// Gets a smaple of the missing thirdPartyType in ThirdPartData
        /// </summary>
        /// <returns></returns>
        public static string GetThirdPartyDataWithMissingType()
        {
            return "{\"Settings\":{\"AuthEndpoint\":\"https://localhost:44304/api/authenticate\",\"Endpoint\":\"https://localhost:44304/case-requests\",\"Username\":\"AUsername1\",\"Password\":\"APassword1\"}}";
        }

    }
}
