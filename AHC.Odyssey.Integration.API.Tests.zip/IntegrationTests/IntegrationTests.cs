﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IntegrationTests.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Tests.IntegrationTests
{
    using System;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using AHC.Odyssey.Integration.API.Tests.Helpers;
    using FluentAssertions;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.TestHost;
    using Serilog;
    using Xunit;

    /// <summary>
    /// Integration test class for controller
    /// </summary>
    public class IntegrationTests 
    {
        /// <summary>
        /// Client object to create HTTP requests
        /// </summary>
        private readonly HttpClient client;

        /// <summary>
        /// Test server used for integration tests to run
        /// </summary>
        private readonly TestServer testServer;
        
        /// <summary>
        /// Initialises an instance of <see cref="IntegrationTests"/> class
        /// </summary>
        public IntegrationTests()
        {
            var builder = new WebHostBuilder()
            .UseStartup<TestStartup>()
            .UseSerilog()
            .UseSetting("RunEnv", "Testing");

            this.testServer = new TestServer(builder);
            this.client = this.testServer.CreateClient();
        }

        /// <summary>
        /// Finalises an instance of <see cref="IntegrationTests"/> class
        /// </summary>
        ~IntegrationTests()
        {
            this.testServer?.Dispose();
        }

        /// <summary>
        /// Tests that Create end point returns a status code of Ok 
        /// </summary>
        /// <returns>HTTP status code</returns>
        [Fact]
        public async Task Post_CreateMapping_ReturnsSuccess()
        {
            //// Arrange
            var request = new
            {
                Url = "/api/map/create",
                Body = new
                {
                    OdysseyPatientDomainId = Guid.NewGuid(),
                    OdysseyCoreDomainId = Guid.NewGuid(),
                    OdysseyServiceUrl = "https://www.ecoverweb.com",
                    ThirdPartyData = ThirdPartyDataHelper.GetValidThirdPartyData(),
                    HasOdysseyCore = true,
                    ReferrerName = "OdysseyED"
                }
            };

            //// Act
            var response = await this.client.PostAsync(request.Url, ContentHelper.GetStringContent(request.Body));

            //// Assert
            response.StatusCode.Should().Be(HttpStatusCode.OK);
        }

        /// <summary>
        /// Tests that Get By Id end point returns a status code of NoContent 
        /// </summary>
        /// <returns>HTTP status code</returns>
        [Fact]
        public async Task GetMapping_ReturnsSuccess()
        {
            //// Arrange
            var request = new
            {
                Url = $"/api/map/{Guid.NewGuid()}"
            };

            //// Act
            var response = await this.client.GetAsync(request.Url);

            //// Assert
            response.EnsureSuccessStatusCode();
            response.StatusCode.Should().Be(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Tests that Get All end point returns a status code of NoContent 
        /// </summary>
        /// <returns>HTTP status code</returns>
        [Fact]
        public async Task GetAllMapping_ReturnsSuccess()
        {
            //// Arrange
            var request = new
            {
                Url = $"/api/map"
            };

            //// Act
            var response = await this.client.GetAsync(request.Url);

            //// Assert
            response.EnsureSuccessStatusCode();
            response.StatusCode.Should().Be(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Tests that Update end point returns a status code of Ok 
        /// </summary>
        /// <returns>HTTP status code</returns>
        [Fact]
        public async Task Post_UpdateMapping_ReturnsSuccess()
        {
            //// Arrange
            var request = new
            {
                Url = "/api/map/update",
                Body = new
                {
                    OdysseyPatientDomainId = Guid.NewGuid(),
                    OdysseyCoreDomainId = Guid.NewGuid(),
                    OdysseyServiceUrl = "https://www.ecoverweb.com",
                    ThirdPartyData = ThirdPartyDataHelper.GetValidThirdPartyData(),
                    HasOdysseyCore = true,
                    ReferrerName = "OdysseyED"
                }
            };

            //// Act
            var response = await this.client.PostAsync(request.Url, ContentHelper.GetStringContent(request.Body));

            //// Assert
            response.StatusCode.Should().Be(HttpStatusCode.NoContent);
        }
    }
}
