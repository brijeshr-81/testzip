﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="TestAuthenticationExtensions.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Tests.IntegrationTests
{
    using System;
    using Microsoft.AspNetCore.Authentication;

    /// <summary>
    /// Extension class for custom authentication builder to be used in Integration Tests
    /// </summary>
    public static class TestAuthenticationExtensions
    {
        /// <summary>
        /// Custom Authentication Builder 
        /// </summary>
        /// <param name="builder">authentication builder</param>
        /// <param name="configureOptions">configurable options</param>
        /// <returns>A configured <see cref="AuthenticationBuilder"/></returns>
        public static AuthenticationBuilder AddTestAuth(this AuthenticationBuilder builder, Action<TestAuthenticationOptions> configureOptions)
        {
            return builder.AddScheme<TestAuthenticationOptions, TestAuthenticationHandler>("Test Scheme", "Test Auth", configureOptions);
        }
    }
}
