﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="TestStartup.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Tests.IntegrationTests
{
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;

    /// <summary>
    /// Custom Start up class for integration tests
    /// </summary>
    public class TestStartup : Startup
    {
        /// <summary>
        /// Initialises an instance of <see cref="TestStartup"/> class
        /// </summary>
        /// <param name="configuration">The application configuration properties</param>
        public TestStartup(IConfiguration configuration) : base(configuration)
        {
        }

        /// <summary>
        /// Configure authentication 
        /// </summary>
        /// <param name="services">Collection of service descriptors</param>
        public override void ConfigureAuthentication(IServiceCollection services)
        {
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = "Test Scheme";
                options.DefaultChallengeScheme = "Test Scheme";
            }).AddTestAuth(o => { });
        }

        /// <summary>
        /// Configure authorization
        /// </summary>
        /// <param name="services">Collection of service descriptors</param>
        public override void ConfigureAuthorization(IServiceCollection services)
        {
            services.AddAuthorization(options =>
            {
                options.AddPolicy("mapping:read", policy => policy.Requirements.Add(new ScopeRequirement("mapping:read", "LOCAL AUTHORITY")));
                options.AddPolicy("mapping:write", policy => policy.Requirements.Add(new ScopeRequirement("mapping:write", $"LOCAL AUTHORITY")));
                options.AddPolicy("import:transfer", policy => policy.Requirements.Add(new ScopeRequirement("import:transfer", $"LOCAL AUTHORITY")));
            });
        }
    }
}
