﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="TestAuthenticationOptions.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Tests.IntegrationTests
{
    using System;
    using System.Security.Claims;
    using Microsoft.AspNetCore.Authentication;

    /// <summary>
    /// Custom authentication options
    /// </summary>
    public class TestAuthenticationOptions : AuthenticationSchemeOptions
    {
        /// <summary>
        /// Gets the identity used for custom authentication
        /// </summary>
        public virtual ClaimsIdentity Identity { get; } = new ClaimsIdentity(
            new Claim[]
            {
                new Claim(ClaimTypes.NameIdentifier, Guid.NewGuid().ToString()),
                new Claim("scope", "mapping:read mapping:write import:transfer"),
                new Claim("Issuer", "LOCAL AUTHORITY")
            }, 
            "test");
    }
}
