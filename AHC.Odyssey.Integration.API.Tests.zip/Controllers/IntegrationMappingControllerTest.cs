﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IntegrationMappingControllerTest.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Tests.Controllers
{
    using System;
    using System.Collections.Generic;
    using AHC.Odyssey.Integration.API.Controllers;
    using AHC.Odyssey.Integration.API.Models;
    using AHC.Odyssey.Integration.API.Services;
    using AHC.Odyssey.Integration.API.Tests.Helpers;
    using Microsoft.AspNetCore.Mvc;
    using Moq;
    using Xunit;

    /// <summary>
    /// Test class for Integration Mapping Controller actions
    /// </summary>
    public class IntegrationMappingControllerTest
    {
        /// <summary>
        /// Field to hold reference of <see cref="IntegrationMappingController"/> class
        /// </summary>
        private readonly IntegrationMappingController controller;

        /// <summary>
        /// Mocked integration service instance
        /// </summary>
        private readonly Mock<IIntegrationService> mockIntegrationService = new Mock<IIntegrationService>();

        /// <summary>
        /// Initialises a new instance of the <see cref="IntegrationMappingControllerTest"/> class.
        /// </summary>
        public IntegrationMappingControllerTest()
        {
            this.controller = new IntegrationMappingController(this.mockIntegrationService.Object);
        }

        #region Create

        /// <summary>
        /// Tests that Create end point returns returns Bad Request  
        /// When no data posted (input is null)
        /// </summary>
        [Fact]
        public void CreateMapping_Return_BadRequest()
        {
            //// Act
            var result = this.controller.CreateMapping(null);

            //// Assert
            Assert.IsType<BadRequestResult>(result);
        }

        /// <summary>
        /// Tests that Create end point returns returns Bad Request  
        /// When some data is null or missing
        /// </summary>
        [Fact]
        public void CreateMapping_Return_BadRequestWithMissingData()
        {
            //// Arrange
            var mappingDetails = new DtoIntegrationMapping()
            {
                OdysseyPatientDomainId = Guid.NewGuid(),
                ThirdPartyData = ThirdPartyDataHelper.GetValidThirdPartyData()
            };

            //// Act
            var result = this.controller.CreateMapping(mappingDetails);

            //// Assert
            Assert.IsType<BadRequestResult>(result);
        }

        /// <summary>
        /// Tests that Create end point returns Bad Request  
        /// When url format is invalid
        /// </summary>
        [Fact]
        public void CreateMapping_Return_BadRequestWithIncorrectUrl()
        {
            //// Arrange
            var mappingDetails = new DtoIntegrationMapping()
            {
                OdysseyPatientDomainId = Guid.NewGuid(),
                OdysseyCoreDomainId = Guid.NewGuid(),
                OdysseyServiceUrl = "www.Adastra.com/Add"
            };

            //// Act
            var result = this.controller.CreateMapping(mappingDetails);

            //// Assert
            Assert.IsType<BadRequestResult>(result);
        }

        /// <summary>
        /// Tests that Create end point returns a status code of BadRequest
        /// When ThirdParty Data is not provided
        /// </summary>
        [Fact]
        public void CreateMapping_Return_BadRequest_WithNoThirdPartyData()
        {
            //// Arrange
            var mappingDetails = new DtoIntegrationMapping()
            {
                OdysseyPatientDomainId = Guid.NewGuid(),
                OdysseyCoreDomainId = Guid.NewGuid(),
                OdysseyServiceUrl = "https://www.odysseyServices"
            };

            this.mockIntegrationService.Setup(i => i.AddMapping(mappingDetails)).Returns(1);

            //// Act
            var result = this.controller.CreateMapping(mappingDetails);

            //// Assert
            Assert.IsType<BadRequestResult>(result);
        }
        
        /// <summary>
        /// Tests that Create end point returns a status code of Ok 
        /// </summary>
        [Fact]
        public void CreateMapping_Return_Ok()
        {
            //// Arrange
            var mappingDetails = this.GetSampleMappingDetails();

            this.mockIntegrationService.Setup(i => i.AddMapping(mappingDetails)).Returns(1);

            //// Act
            var result = this.controller.CreateMapping(mappingDetails);

            //// Assert
            Assert.IsType<OkResult>(result);
        }

        /// <summary>
        /// Tests that Create end point returns a status code of 409
        /// When there is already a record with the given Odyssey Patient Id
        /// </summary>
        [Fact]
        public void CreateMapping_Return_Conflict()
        {
            //// Arrange
            var mappingDetails = this.GetSampleMappingDetails();

            this.mockIntegrationService.Setup(i => i.AddMapping(mappingDetails)).Returns(0);

            //// Act
            var result = this.controller.CreateMapping(mappingDetails);

            //// Assert
            Assert.IsType<ConflictResult>(result);
        }

        /// <summary>
        /// Tests Create Mapping end point throws InvalidOperationException
        /// </summary>
        [Fact]
        public void CreateMapping_Throws_InvalidOperationException()
        {
            //// Arrange
            var mappingDetails = this.GetSampleMappingDetails();

            this.mockIntegrationService.Setup(i => i.AddMapping(mappingDetails)).Throws(new Exception());

            //// Assert and Act
            Assert.Throws<InvalidOperationException>(() => this.controller.CreateMapping(mappingDetails));
        }
        #endregion

        #region GetById

        /// <summary>
        /// Tests that Get By Id end point returns a status code of Ok 
        /// </summary>
        [Fact]
        public void GetMapping_Return_Ok()
        {
            //// Arrange
            var odysseyPatientId = Guid.NewGuid();
            var mappingDetails = this.GetSampleMappingDetailsWithOdysseyPatientId(odysseyPatientId);

            this.mockIntegrationService.Setup(i => i.GetMappingByOdysseyPatientId(odysseyPatientId)).Returns(mappingDetails);

            //// Act
            var result = this.controller.GetMapping(odysseyPatientId);

            //// Assert
            Assert.IsType<OkObjectResult>(result);
        }

        /// <summary>
        /// Tests that Get By Id end point returns a Bad Request response when an empty Guid is passed
        /// </summary>
        [Fact]
        public void GetMapping_Return_BadRequest()
        {
            var odysseyPatientId = Guid.Empty;
            var mappingDetails = this.GetSampleMappingDetailsWithOdysseyPatientId(odysseyPatientId);

            this.mockIntegrationService.Setup(i => i.GetMappingByOdysseyPatientId(odysseyPatientId)).Returns(mappingDetails);

            //// Act
            var result = this.controller.GetMapping(odysseyPatientId);

            //// Assert
            Assert.IsType<BadRequestResult>(result);
        }

        /// <summary>
        /// Tests that Get By Id end point returns a response of NoContent
        /// When there is no mapping found for a given odyssey patient Id
        /// </summary>
        [Fact]
        public void GetMapping_Return_NoContent()
        {
            //// Arrange    
            var odysseyPatientId = Guid.NewGuid();
            DtoIntegrationMapping integrationMapping = null;
            this.mockIntegrationService.Setup(i => i.GetMappingByOdysseyPatientId(odysseyPatientId)).Returns(integrationMapping);

            //// Act
            var result = this.controller.GetMapping(odysseyPatientId);

            //// result
            Assert.IsType<NoContentResult>(result);
        }

        /// <summary>
        /// Tests that Get By Id end point throws InvalidOperationException
        /// </summary>
        [Fact]
        public void GetMapping_Throws_InvalidOperationException()
        {
            //// Arrange    
            var odysseyPatientId = Guid.NewGuid();
            this.mockIntegrationService.Setup(i => i.GetMappingByOdysseyPatientId(odysseyPatientId)).Throws(new Exception());

            //// Assert and Act
            Assert.Throws<InvalidOperationException>(() => this.controller.GetMapping(odysseyPatientId));
        }

        #endregion

        #region Update

        /// <summary>
        /// Tests that Update end point returns returns Bad Request  
        /// When no data posted (input is null)
        /// </summary>
        [Fact]
        public void UpdateMapping_Return_BadRequest()
        {
            //// Act
            var result = this.controller.UpdateMapping(null);

            //// Assert
            Assert.IsType<BadRequestResult>(result);
        }

        /// <summary>
        /// Tests that Update end point returns returns Bad Request  
        /// When some data is null or missing
        /// </summary>
        [Fact]
        public void UpdateMapping_Return_BadRequestWithMissingData()
        {
            //// Arrange
            var mappingDetails = new DtoIntegrationMapping()
            {
                OdysseyPatientDomainId = Guid.NewGuid(),
                ThirdPartyData = ThirdPartyDataHelper.GetValidThirdPartyData()
            };

            //// Act
            var result = this.controller.UpdateMapping(mappingDetails);

            //// Assert
            Assert.IsType<BadRequestResult>(result);
        }

        /// <summary>
        /// Tests that Update end point returns returns Bad Request  
        /// When url format is invalid
        /// </summary>
        [Fact]
        public void UpdateMapping_Return_BadRequestWithIncorrectUrl()
        {
            //// Arrange
            var mappingDetails = new DtoIntegrationMapping()
            {
                OdysseyPatientDomainId = Guid.NewGuid(),
                OdysseyCoreDomainId = Guid.NewGuid(),
                OdysseyServiceUrl = "www.Adastra.com/Add"
            };

            //// Act
            var result = this.controller.UpdateMapping(mappingDetails);

            //// Assert
            Assert.IsType<BadRequestResult>(result);
        }

        /// <summary>
        /// Tests that Update end point returns a status code of Bad Request
        /// </summary>
        [Fact]
        public void UpdateMapping_Return_BadRequestWithNoThirdPartyData()
        {
            //// Arrange
            var mappingDetails = new DtoIntegrationMapping()
            {
                OdysseyPatientDomainId = Guid.NewGuid(),
                OdysseyCoreDomainId = Guid.NewGuid(),
                OdysseyServiceUrl = "https://www.odysseyServices",
            };

            bool alreadyUpdated;
            this.mockIntegrationService.Setup(i => i.UpdateMapping(mappingDetails, out alreadyUpdated)).Returns(1);

            //// Act
            var result = this.controller.UpdateMapping(mappingDetails);

            //// Assert
            Assert.IsType<BadRequestResult>(result);
        }

        /// <summary>
        /// Tests that Update end point returns a status code of Ok 
        /// </summary>
        [Fact]
        public void UpdateMapping_Return_Ok()
        {
            //// Arrange
            var mappingDetails = this.GetSampleMappingDetails();

            bool alreadyUpdated;
            this.mockIntegrationService.Setup(i => i.UpdateMapping(mappingDetails, out alreadyUpdated)).Returns(1);

            //// Act
            var result = this.controller.UpdateMapping(mappingDetails);

            //// Assert
            Assert.IsType<OkResult>(result);
        }

        /// <summary>
        /// Tests that Update end point returns a response of No content
        /// When there is no record found for the given Odyssey Patient Id
        /// </summary>
        [Fact]
        public void UpdateMapping_Return_NoContent()
        {
            //// Arrange
            var mappingDetails = this.GetSampleMappingDetails();

            bool alreadyUpdated;
            this.mockIntegrationService.Setup(i => i.UpdateMapping(mappingDetails, out alreadyUpdated)).Returns(0);

            //// Act
            var result = this.controller.UpdateMapping(mappingDetails);

            //// Assert
            Assert.IsType<NoContentResult>(result);
        }

        /// <summary>
        /// Tests that Update end point throws InvalidOperationException
        /// </summary>
        [Fact]
        public void UpdateMapping_Throws_InvalidOperationException()
        {
            //// Arrange
            var mappingDetails = this.GetSampleMappingDetails();

            bool alreadyUpdated;
            this.mockIntegrationService.Setup(i => i.UpdateMapping(mappingDetails, out alreadyUpdated)).Throws(new Exception());

            //// Assert and Act
            Assert.Throws<InvalidOperationException>(() => this.controller.UpdateMapping(mappingDetails));
        }

        /// <summary>
        /// Tests that Update end point returns already updated string when its available in the database.
        /// </summary>
        [Fact]
        public void UpdateMapping_Return_AlreadyUpdated()
        {
            //// Arrange
            var mappingDetails = this.GetSampleMappingDetails();

            bool alreadyUpdated = true;
            this.mockIntegrationService.Setup(i => i.UpdateMapping(mappingDetails, out alreadyUpdated)).Returns(0);

            //// Act
            var result = this.controller.UpdateMapping(mappingDetails);
            var objectResponse = result as ObjectResult;

            //// Assert
            Assert.Equal("The given record already updated", objectResponse.Value);
        }

        #endregion

        #region GetAll

        /// <summary>
        /// Tests that Get All end point returns a status code of Ok 
        /// </summary>
        [Fact]
        public void GetAllMapping_Return_Ok()
        {
            //// Arrange
            var mappingDetails = this.GetSampleMappingDetailsList();

            this.mockIntegrationService.Setup(i => i.GetAllMapping()).Returns(mappingDetails);

            //// Act
            var result = this.controller.GetAllMapping();

            //// Assert
            Assert.IsType<OkObjectResult>(result);
        }

        /// <summary>
        /// Tests that Get All end point returns a response of NoContent
        /// When there are no mapping details found 
        /// </summary>
        [Fact]
        public void GetAllMapping_Return_NoContent()
        {
            //// Arrange    
            List<DtoIntegrationMapping> integrationMappingList = null;
            this.mockIntegrationService.Setup(i => i.GetAllMapping()).Returns(integrationMappingList);

            //// Act
            var result = this.controller.GetAllMapping();

            //// result
            Assert.IsType<NoContentResult>(result);
        }

        /// <summary>
        /// Tests that Get All point throws InvalidOperationException
        /// </summary>
        [Fact]
        public void GetAllMapping_Throws_InvalidOperationException()
        {
            //// Arrange    
            this.mockIntegrationService.Setup(i => i.GetAllMapping()).Throws(new Exception());

            //// Assert and Act
            Assert.Throws<InvalidOperationException>(() => this.controller.GetAllMapping());
        }

        #endregion

        #region private_methods

        /// <summary>
        /// Gets a sample mapping details object
        /// </summary>
        /// <returns>an object of type <see cref="DtoIntegrationMapping"/></returns>
        private DtoIntegrationMapping GetSampleMappingDetails()
        {
            return new DtoIntegrationMapping()
            {
                OdysseyPatientDomainId = Guid.NewGuid(),
                OdysseyCoreDomainId = Guid.NewGuid(),
                OdysseyServiceUrl = "https://www.ecoverweb.com",
                ThirdPartyData = ThirdPartyDataHelper.GetValidThirdPartyData(),
                HasOdysseyCore = true,
                ReferrerName = "OdysseyED"
            };
        }

        /// <summary>
        /// Gets a sample mapping details object with a given odyssey patient Id
        /// </summary>
        /// <param name="odysseyPatientId">Odyssey Patient Id with with mapping details to be created</param>
        /// <returns>an object of type <see cref="DtoIntegrationMapping"/></returns>
        private DtoIntegrationMapping GetSampleMappingDetailsWithOdysseyPatientId(Guid odysseyPatientId)
        {
            return new DtoIntegrationMapping()
            {
                OdysseyPatientDomainId = odysseyPatientId,
                OdysseyCoreDomainId = Guid.NewGuid(),
                OdysseyServiceUrl = "https://www.ecoverweb.com",
                ThirdPartyData = ThirdPartyDataHelper.GetValidThirdPartyData(),
                HasOdysseyCore = true,
                ReferrerName = "OdysseyED"
            };
        }

        /// <summary>
        /// Gets a sample mapping details list
        /// </summary>
        /// <returns>a list of type <see cref="DtoIntegrationMapping"/></returns>
        private List<DtoIntegrationMapping> GetSampleMappingDetailsList()
        {
            return new List<DtoIntegrationMapping>()
            {
                new DtoIntegrationMapping()
                {
                    OdysseyPatientDomainId = Guid.NewGuid(),
                    OdysseyCoreDomainId = Guid.NewGuid(),
                    OdysseyServiceUrl = "https://www.ecoverweb.com",
                    ThirdPartyData = ThirdPartyDataHelper.GetValidThirdPartyData(),
                    HasOdysseyCore = true,
                    ReferrerName = "OdysseyED"
                } 
            };
        }

        #endregion
    }
}
