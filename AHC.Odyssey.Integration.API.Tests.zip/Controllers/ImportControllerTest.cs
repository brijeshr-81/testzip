﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ImportControllerTest.cs" company="Advanced Health & Care">
//   Copyright © Advanced Health & Care 2020
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AHC.Odyssey.Integration.API.Tests.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Net;
    using System.Net.Http;
    using System.Text;
    using AHC.Odyssey.Integration.API.Controllers;
    using AHC.Odyssey.Integration.API.Models;
    using AHC.Odyssey.Integration.API.Services;
    using AHC.Odyssey.Integration.API.Tests.Helpers;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Primitives;
    using Moq;
    using Newtonsoft.Json;
    using Xunit;

    /// <summary>
    /// Test class for Import Controller class
    /// </summary>
    public class ImportControllerTest
    {
        /// <summary>
        /// Mocked Import service instance
        /// </summary>
        private readonly Mock<IImportService> mockImportService = new Mock<IImportService>();

        /// <summary>
        /// Mock Logger for import controller
        /// </summary>
        private readonly Mock<ILogger<ImportController>> mockImportControllerLogger = new Mock<ILogger<ImportController>>();

        /// <summary>
        /// Mocked integration service instance
        /// </summary>
        private readonly Mock<IIntegrationService> mockIntegrationService = new Mock<IIntegrationService>();

        /// <summary>
        /// Mocked Third Party service instance
        /// </summary>
        private readonly Mock<IThirdPartyService> mockThirdPartyService = new Mock<IThirdPartyService>();

        /// <summary>
        /// Mocked integration mapping record
        /// </summary>
        private readonly DtoIntegrationMapping mappingRecord = new DtoIntegrationMapping
        {
            OdysseyPatientDomainId = Guid.NewGuid(),
            OdysseyCoreDomainId = Guid.NewGuid(),
            OdysseyServiceUrl = "https://localhost:44357/",
            ThirdPartyData = ThirdPartyDataHelper.GetValidThirdPartyData(),
            HasOdysseyCore = true,
            ReferrerName = "OdysseyED"
        };

        /// <summary>
        /// Unit Test to transfer data end to end including third party service
        /// Returns action result as Ok object result
        /// </summary>
        [Fact]
        public void TransferData_ValidReturnOk()
        {
            // Arrange
            var fakeConfiguration = new Mock<IConfiguration>();
            fakeConfiguration.SetupGet(m => m["ImportServiceUrl"]).Returns(this.mappingRecord.OdysseyServiceUrl);

            var httpContext = new DefaultHttpContext();
            var transactionId = Guid.NewGuid();
            var file = new FormFile(new MemoryStream(Encoding.UTF8.GetBytes("This is a dummy file")), 0, 0, "Data", "dummy.txt");
            var callbackNumber = "01234567987";
            httpContext.Request.Headers.Add("Content-Type", "multipart/form-data");
            httpContext.Request.Form = new FormCollection(new Dictionary<string, StringValues> { { "callbackNumber", callbackNumber }, { "transactionId", transactionId.ToString() } }, new FormFileCollection { file });
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(Guid.NewGuid().ToString()), Encoding.UTF8, "application/json")
            };

            this.mockImportService.Setup(i => i.TransferData(this.mappingRecord.OdysseyCoreDomainId, this.mappingRecord.OdysseyServiceUrl, file, transactionId)).Returns(response);
            this.mockIntegrationService.Setup(m => m.GetMappingByOdysseyPatientId(this.mappingRecord.OdysseyPatientDomainId)).Returns(this.mappingRecord);
            this.mockThirdPartyService.Setup(t => t.SendAssessmentToThirdParty(It.IsAny<IFormCollection>(), transactionId, this.mappingRecord.ReferrerName)).Returns(true);

            var importController = new ImportController(this.mockImportService.Object, this.mockIntegrationService.Object, this.mockThirdPartyService.Object, fakeConfiguration.Object, this.mockImportControllerLogger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = httpContext
                }
            };

            // Act
            var result = importController.TransferData(this.mappingRecord.OdysseyPatientDomainId);

            // Assert
            Assert.IsType<OkObjectResult>(result);
        }

        /// <summary>
        /// Unit Test to transfer data end to end including third party service
        /// Returns action result as Ok object result
        /// </summary>
        [Fact]
        public void TransferData_ThirdPartyService_Failure()
        {
            //// Arrange
            var fakeConfiguration = new Mock<IConfiguration>();
            fakeConfiguration.SetupGet(m => m["ImportServiceUrl"]).Returns(this.mappingRecord.OdysseyServiceUrl);

            var httpContext = new DefaultHttpContext();
            var transactionId = Guid.NewGuid();
            var file = new FormFile(new MemoryStream(Encoding.UTF8.GetBytes("This is a dummy file")), 0, 0, "Data", "dummy.txt");
            var callbackNumber = "01234567987";
            httpContext.Request.Headers.Add("Content-Type", "multipart/form-data");
            httpContext.Request.Form = new FormCollection(new Dictionary<string, StringValues> { { "callbackNumber", callbackNumber }, { "transactionId", transactionId.ToString() } }, new FormFileCollection { file });
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(Guid.NewGuid().ToString()), Encoding.UTF8, "application/json")
            };

            this.mockImportService.Setup(i => i.TransferData(this.mappingRecord.OdysseyCoreDomainId, this.mappingRecord.OdysseyServiceUrl, file, transactionId)).Returns(response);
            this.mockIntegrationService.Setup(m => m.GetMappingByOdysseyPatientId(this.mappingRecord.OdysseyPatientDomainId)).Returns(this.mappingRecord);
            this.mockThirdPartyService.Setup(t => t.SendAssessmentToThirdParty(It.IsAny<IFormCollection>(), transactionId, this.mappingRecord.ReferrerName)).Returns(false);

            var importController = new ImportController(this.mockImportService.Object, this.mockIntegrationService.Object, this.mockThirdPartyService.Object, fakeConfiguration.Object, this.mockImportControllerLogger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = httpContext
                }
            };

            //// Act
            var result = importController.TransferData(this.mappingRecord.OdysseyPatientDomainId);

            //// Assert
            Assert.IsType<ObjectResult>(result);
            var objectResponse = result as ObjectResult;
            Assert.Equal(500, objectResponse.StatusCode);
        }

        /// <summary>
        /// Unit Test to transfer data with no import service url
        /// Returns action result Bad request object result
        /// </summary>
        [Fact]
        public void TransferData_InvalidUrlReturnBadRequest()
        {
            // Arrange
            var fakeConfiguration = new Mock<IConfiguration>();
            fakeConfiguration.SetupGet(m => m["ImportServiceUrl"]).Returns(this.mappingRecord.OdysseyServiceUrl);

            var httpContext = new DefaultHttpContext();
            var transactionId = Guid.NewGuid();
            var callbackNumber = "01234567987";
            var file = new FormFile(new MemoryStream(Encoding.UTF8.GetBytes("This is a dummy file")), 0, 0, "Data", "dummy.txt");
            httpContext.Request.Headers.Add("Content-Type", "multipart/form-data");
            httpContext.Request.Form = new FormCollection(new Dictionary<string, StringValues> { { "callbackNumber", callbackNumber }, { "transactionId", transactionId.ToString() } }, new FormFileCollection { file });

            this.mockImportService.Setup(i => i.TransferData(this.mappingRecord.OdysseyCoreDomainId, this.mappingRecord.OdysseyServiceUrl, file, transactionId)).Returns(new HttpResponseMessage() { StatusCode = HttpStatusCode.BadRequest });
            this.mockIntegrationService.Setup(m => m.GetMappingByOdysseyPatientId(this.mappingRecord.OdysseyPatientDomainId)).Returns(this.mappingRecord);

            var importController = new ImportController(this.mockImportService.Object, this.mockIntegrationService.Object, this.mockThirdPartyService.Object, fakeConfiguration.Object, this.mockImportControllerLogger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = httpContext
                }
            };

            // Act
            var result = importController.TransferData(this.mappingRecord.OdysseyPatientDomainId);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }

        /// <summary>
        /// Unit Test to transfer data with valid message text but invalid import service url
        /// Returns action result as Bad request object result
        /// </summary>
        [Fact]
        public void TransferData_InvalidReturnBadRequest()
        {
            // Arrange
            var fakeConfiguration = new Mock<IConfiguration>();
            fakeConfiguration.SetupGet(m => m["ImportServiceUrl"]).Returns(this.mappingRecord.OdysseyServiceUrl);

            var httpContext = new DefaultHttpContext();
            var file = new FormFile(new MemoryStream(Encoding.UTF8.GetBytes("This is a dummy file")), 0, 0, "Data", "dummy.txt");
            var transactionId = Guid.NewGuid();
            var callbackNumber = "01234567987";
            httpContext.Request.Headers.Add("Content-Type", "multipart/form-data");
            httpContext.Request.Form = new FormCollection(new Dictionary<string, StringValues> { { "callbackNumber", callbackNumber }, { "transactionId", transactionId.ToString() } }, new FormFileCollection { file });

            this.mockImportService.Setup(i => i.TransferData(this.mappingRecord.OdysseyCoreDomainId, this.mappingRecord.OdysseyServiceUrl, file, transactionId)).Returns(new HttpResponseMessage() { StatusCode = HttpStatusCode.BadRequest });
            this.mockIntegrationService.Setup(m => m.GetMappingByOdysseyPatientId(this.mappingRecord.OdysseyPatientDomainId)).Returns(this.mappingRecord);

            var importController = new ImportController(this.mockImportService.Object, this.mockIntegrationService.Object, this.mockThirdPartyService.Object, fakeConfiguration.Object, this.mockImportControllerLogger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = httpContext
                }
            };

            // Act
            var result = importController.TransferData(this.mappingRecord.OdysseyPatientDomainId);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }

        /// <summary>
        /// Unit Test to transfer data with valid message text but invalid import service url
        /// Returns action result as Bad request object result
        /// </summary>
        [Fact]
        public void TransferData_InvalidReturnInternalServerError()
        {
            // Arrange
            var fakeConfiguration = new Mock<IConfiguration>();
            fakeConfiguration.SetupGet(m => m["ImportServiceUrl"]).Returns(this.mappingRecord.OdysseyServiceUrl);

            var httpContext = new DefaultHttpContext();
            var transactionId = Guid.NewGuid();
            var callbackNumber = "01234567987";
            httpContext.Request.Headers.Add("Content-Type", "multipart/form-data");
            var file = new FormFile(new MemoryStream(Encoding.UTF8.GetBytes("This is a dummy file")), 0, 0, "Data", "dummy.txt");
            httpContext.Request.Form = new FormCollection(new Dictionary<string, StringValues> { { "callbackNumber", callbackNumber }, { "transactionId", transactionId.ToString() } }, new FormFileCollection { file });

            this.mockImportService.Setup(i => i.TransferData(this.mappingRecord.OdysseyCoreDomainId, this.mappingRecord.OdysseyServiceUrl, file, transactionId)).Returns(new HttpResponseMessage() { StatusCode = HttpStatusCode.InternalServerError });
            this.mockIntegrationService.Setup(m => m.GetMappingByOdysseyPatientId(this.mappingRecord.OdysseyPatientDomainId)).Returns(this.mappingRecord);
            var importController = new ImportController(this.mockImportService.Object, this.mockIntegrationService.Object, this.mockThirdPartyService.Object, fakeConfiguration.Object, this.mockImportControllerLogger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = httpContext
                }
            };

            // Arrange
            var result = importController.TransferData(this.mappingRecord.OdysseyPatientDomainId);

            // Assert
            Assert.IsType<ObjectResult>(result);
            var objectResponse = result as ObjectResult;
            Assert.Equal(500, objectResponse.StatusCode);
        }

        /// <summary>
        /// Unit Test to transfer data with transfer file not available in Request
        /// Returns action result as Bad request object result
        /// </summary>
        [Fact]
        public void TransferData_Request_Files_UnAvailable()
        {
            // Arrange
            var fakeLogger = new Mock<ILogger<ImportController>>();

            var fakeConfiguration = new Mock<IConfiguration>();
            fakeConfiguration.SetupGet(m => m["ImportServiceUrl"]).Returns(this.mappingRecord.OdysseyServiceUrl);

            var httpContext = new DefaultHttpContext();
            var file = new FormFile(new MemoryStream(Encoding.UTF8.GetBytes("This is a dummy file")), 0, 0, "Data", "dummy.txt");
            var transactionId = Guid.NewGuid();
            var callbackNumber = "01234567987";
            httpContext.Request.Headers.Add("Content-Type", "multipart/form-data");
            httpContext.Request.Form = new FormCollection(new Dictionary<string, StringValues> { { "callbackNumber", callbackNumber }, { "transactionId", transactionId.ToString() } }, new FormFileCollection { file });

            this.mockImportService.Setup(i => i.TransferData(this.mappingRecord.OdysseyCoreDomainId, this.mappingRecord.OdysseyServiceUrl, file, transactionId)).Returns(new HttpResponseMessage() { StatusCode = HttpStatusCode.BadRequest });
            this.mockIntegrationService.Setup(m => m.GetMappingByOdysseyPatientId(this.mappingRecord.OdysseyPatientDomainId)).Returns(this.mappingRecord);
            
            var importController = new ImportController(this.mockImportService.Object, this.mockIntegrationService.Object, this.mockThirdPartyService.Object, fakeConfiguration.Object, fakeLogger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = httpContext
                }
            };

            // Act
            var result = importController.TransferData(this.mappingRecord.OdysseyPatientDomainId);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }

        /// <summary>
        /// Unit Test to transfer data with transfer file not available in Request
        /// Returns action result as Bad request object result
        /// </summary>
        [Fact]
        public void TransferData_Request_Domain_Not_Found()
        {
            // Arrange
            var fakeLogger = new Mock<ILogger<ImportController>>();

            var fakeConfiguration = new Mock<IConfiguration>();
            fakeConfiguration.SetupGet(m => m["ImportServiceUrl"]).Returns(this.mappingRecord.OdysseyServiceUrl);

            var httpContext = new DefaultHttpContext();
            var file = new FormFile(new MemoryStream(Encoding.UTF8.GetBytes("This is a dummy file")), 0, 0, "Data", "dummy.txt");
            var transactionId = Guid.NewGuid();
            var callbackNumber = "01234567987";
            httpContext.Request.Headers.Add("Content-Type", "multipart/form-data");
            httpContext.Request.Form = new FormCollection(new Dictionary<string, StringValues> { { "callbackNumber", callbackNumber }, { "transactionId", transactionId.ToString() } }, new FormFileCollection { file });

            this.mockImportService.Setup(i => i.TransferData(this.mappingRecord.OdysseyCoreDomainId, this.mappingRecord.OdysseyServiceUrl, file, transactionId)).Returns(new HttpResponseMessage() { StatusCode = HttpStatusCode.BadRequest });
            this.mockIntegrationService.Setup(m => m.GetMappingByOdysseyPatientId(this.mappingRecord.OdysseyPatientDomainId)).Returns<DtoIntegrationMapping>(null);

            var importController = new ImportController(this.mockImportService.Object, this.mockIntegrationService.Object, this.mockThirdPartyService.Object, fakeConfiguration.Object, fakeLogger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = httpContext
                }
            };

            // Act
            var result = importController.TransferData(this.mappingRecord.OdysseyPatientDomainId);

            // Assert
            Assert.IsType<ObjectResult>(result);
            var objectResponse = result as ObjectResult;
            Assert.Equal(500, objectResponse.StatusCode);
        }

        /// <summary>
        /// Unit Test to transfer data with transfer file not available in Request
        /// Returns action result as Bad request object result
        /// </summary>
        [Fact]
        public void TransferData_Request_Domain_Core_Url_Blank()
        {
            // Arrange
            var fakeConfiguration = new Mock<IConfiguration>();
            fakeConfiguration.SetupGet(m => m["ImportServiceUrl"]).Returns(this.mappingRecord.OdysseyServiceUrl);

            var httpContext = new DefaultHttpContext();
            var file = new FormFile(new MemoryStream(Encoding.UTF8.GetBytes("This is a dummy file")), 0, 0, "Data", "dummy.txt");
            var transactionId = Guid.NewGuid();
            var callbackNumber = "01234567987";
            httpContext.Request.Headers.Add("Content-Type", "multipart/form-data");
            httpContext.Request.Form = new FormCollection(new Dictionary<string, StringValues> { { "callbackNumber", callbackNumber }, { "transactionId", transactionId.ToString() } }, new FormFileCollection { file });

            this.mockImportService.Setup(i => i.TransferData(this.mappingRecord.OdysseyCoreDomainId, this.mappingRecord.OdysseyServiceUrl, file, transactionId)).Returns(new HttpResponseMessage() { StatusCode = HttpStatusCode.InternalServerError });
            this.mockIntegrationService.Setup(m => m.GetMappingByOdysseyPatientId(this.mappingRecord.OdysseyPatientDomainId)).Returns(new DtoIntegrationMapping { OdysseyPatientDomainId = Guid.NewGuid(), OdysseyCoreDomainId = Guid.NewGuid(), OdysseyServiceUrl = string.Empty, ThirdPartyData = string.Empty, HasOdysseyCore = true });
            var importController = new ImportController(this.mockImportService.Object, this.mockIntegrationService.Object, this.mockThirdPartyService.Object, fakeConfiguration.Object, this.mockImportControllerLogger.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = httpContext
                }
            };

            // Act
            var result = importController.TransferData(this.mappingRecord.OdysseyPatientDomainId);

            // Assert
            Assert.IsType<ObjectResult>(result);
            var objectResponse = result as ObjectResult;
            Assert.Equal(500, objectResponse.StatusCode);
        }
    }
}
